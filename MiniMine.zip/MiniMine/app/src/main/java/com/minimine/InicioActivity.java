package com.minimine;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.EditText;
import java.util.Random;

public class InicioActivity extends Activity {
    
	private EditText seed, tipoMundo;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mundo);
		
		seed = findViewById(R.id.seed);
		tipoMundo = findViewById(R.id.tipoMundo);
    }
	
	public void paraJogo(View v) {
		Intent mundo = new Intent(this, MundoActivity.class);
		
		if(!seed.getText().toString().equals("")) mundo.putExtra("seed", Integer.parseInt(seed.getText().toString()));
		else {
			Random aleatorio = new Random();
			mundo.putExtra("seed", aleatorio.nextInt(99999999));
			mundo.putExtra("tipoMundo", tipoMundo.getText().toString());
		}
		
		startActivity(mundo);
	}
}
