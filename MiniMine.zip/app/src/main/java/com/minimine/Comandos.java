package com.minimine;

import android.widget.*;

public class Comandos {
	
	private GLRender render;
	private EditText chat;
    
	public Comandos(GLRender render, EditText chat) {
		this.render = render;
		this.chat = chat;
	}
	
    public void executar(String comando) {
		try {
			// tp:
			if(comando.startsWith("/tp ")) {
				comando = comando.replace("/tp ", "");
				String[] tokens = comando.split(" ");
				
				float x = Float.parseFloat(tokens[0].replace("~", String.valueOf(render.camera.posicao[0])));
				float y = Float.parseFloat(tokens[1].replace("~", String.valueOf(render.camera.posicao[1])));
				float z = Float.parseFloat(tokens[2].replace("~", String.valueOf(render.camera.posicao[2])));
				render.camera.posicao[0] = x;
				render.camera.posicao[1] = y;
				render.camera.posicao[2] = z;
				
				comando = "jogador teleportado para X: "+x+", Y: "+y+", Z: "+z;
				// chunk:
			} else if(comando.startsWith("/chunk raio ")) {
				comando = comando.replace("/chunk raio ", "");

				render.mundo.RAIO_CARREGAMENTO = Integer.parseInt(comando);
				
				comando = "chunks ao redor do jogador: "+render.mundo.CHUNK_TAMANHO*render.mundo.RAIO_CARREGAMENTO;
			} else if(comando.startsWith("/chunk tamanho")) {
				comando = comando.replace("/chunk tamanho ", "");

				render.mundo.CHUNK_TAMANHO = Integer.parseInt(comando);
				
				comando = "tamanho de chunk definido para "+render.mundo.CHUNK_TAMANHO+" blocos de largura";
				// bloco:
			} else if(comando.startsWith("/bloco ")) {
				comando = comando.replace("/bloco ", "");
				String[] tokens = comando.trim().split(" ");

				TipoBloco tipo = TipoBloco.GRAMA;

				switch(tokens[3]) {
					case "ar":
						tipo = TipoBloco.AR;
						break;
					case "grama":
						tipo = TipoBloco.GRAMA;
						break;
					case "terra":
						tipo = TipoBloco.TERRA;
						break;
					case "pedra":
						tipo = TipoBloco.PEDRA;
						break;
					case "pedregulho":
						tipo = TipoBloco.PEDREGULHO;
						break;
					case "tabuas_carvalho":
						tipo = TipoBloco.TABUAS_CARVALHO;
						break;
					case "bedrock":
						tipo = TipoBloco.BEDROCK;
						break;
					default:
						System.out.print(tokens[3]+" isso não é um bloco disponivel");
						break;
				}
				if(tipo != null) {
					float x = Float.parseFloat(tokens[0].replace("~", String.valueOf(render.camera.posicao[0])));
					float y = Float.parseFloat(tokens[1].replace("~", String.valueOf(render.camera.posicao[1])));
					float z = Float.parseFloat(tokens[2].replace("~", String.valueOf(render.camera.posicao[2])));
					render.mundo.colocarBloco(x, y, z, tipo);
					
					comando = "bloco "+tipo+" adicionado na posição X: "+x+", Y: "+y+" Z: "+z;
					} else System.out.println("comando invalido");
					
				// player:
			} else if(comando.startsWith("/player mao")) {
				comando = comando.replace("/player mao ", "");

				switch(comando) {
					case "ar":
						render.camera.itemMao = TipoBloco.AR;
						break;
					case "grama":
						render.camera.itemMao = TipoBloco.GRAMA;
						break;
					case "terra":
						render.camera.itemMao = TipoBloco.TERRA;
						break;
					case "pedra":
						render.camera.itemMao = TipoBloco.PEDRA;
						break;
					case "pedregulho":
						render.camera.itemMao = TipoBloco.PEDREGULHO;
						break;
					case "tabuas_carvalho":
						render.camera.itemMao = TipoBloco.TABUAS_CARVALHO;
						break;
					case "bedrock":
						render.camera.itemMao = TipoBloco.BEDROCK;
						break;
				}
			} else if(comando.startsWith("/player passo ")) {
				comando = comando.replace("/player passo ", "");
				render.camera.velocidade = Float.parseFloat(comando);
			} else if(comando.startsWith("/player peso ")) {
				comando = comando.replace("/player peso ", "");

				render.camera.peso = Float.parseFloat(comando);
			} else if(comando.startsWith("/player hitbox[0] ")) {
				comando = comando.replace("/player hitbox[0] ", "");

				render.camera.hitbox[0] = Float.parseFloat(comando);
			} else if(comando.startsWith("/player hitbox[1] ")) {
				comando = comando.replace("/player hitbox[1] ", "");

				render.camera.hitbox[1] = Float.parseFloat(comando);
				// debug:
			} else if(comando.startsWith("/debug hitbox ")) {
				comando = comando.replace("/debug hitbox ", "");
				
				if(comando.equals("0")) {
					render.debug = false;
					comando = "debug desativado";
				}
				else if(comando.equals("1")) {
					render.debug = true;
					comando = "debug ativado";
				}
			}
			chat.setText("");
			System.out.println(comando);
		} catch(Exception e) {
			System.out.println("erro: " + e.getMessage());
			e.printStackTrace();
		}
    }
}
