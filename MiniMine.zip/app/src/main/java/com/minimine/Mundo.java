package com.minimine;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES20;
import android.opengl.GLUtils;
import java.nio.FloatBuffer;

public class Mundo {
    private static final int CHUNK_TAMANHO = 16;
    private static final int MUNDO_LATERAL = 32;

    private Bloco[][][] blocos;
    private int[] texturas;
    private int shaderPrograma;
    private int lidarvPMatriz;
    private int lidarPosicao;
    private int lidarTexCoord;
    private int lidarTexturas;

    public Mundo() {
        gerarMundo();
    }

    private void gerarMundo() {
        blocos = new Bloco[CHUNK_TAMANHO][MUNDO_LATERAL][CHUNK_TAMANHO];

        for(int x = 0; x < CHUNK_TAMANHO; x++) {
            for(int z = 0; z < CHUNK_TAMANHO; z++) {
                float valorNoise = PerlinNoise.ruido(x/10f, z/10f);
                int lateral = (int)(valorNoise * 10 + 32);

                for(int y = 0; y < MUNDO_LATERAL; y++) {
                    TipoBloco tipo = TipoBloco.AR;
                    if(y == 0) {
                        tipo = TipoBloco.BEDROCK;
                    } else if(y < lateral - 4) {
                        tipo = TipoBloco.PEDRA;
                    } else if(y < lateral) {
                        tipo = TipoBloco.TERRA;
                    } else if(y == lateral) {
                        tipo = TipoBloco.GRAMA;
                    }
                    blocos[x][y][z] = new Bloco(x, y, z, tipo);
                }
            }
        }
    }

    public void initShaders(Context contexto) {
        String verticesShader = ShaderUtils.lerShaderDoRaw(contexto, R.raw.vertices_shader);
        String fragmentoShader = ShaderUtils.lerShaderDoRaw(contexto, R.raw.fragmento_shader);
        shaderPrograma = ShaderUtils.criarPrograma(verticesShader, fragmentoShader);

        lidarvPMatriz = GLES20.glGetUniformLocation(shaderPrograma, "u_VPMatriz");
        lidarPosicao = GLES20.glGetAttribLocation(shaderPrograma, "a_Posicao");
        lidarTexCoord = GLES20.glGetAttribLocation(shaderPrograma, "a_TexCoord");
        lidarTexturas = GLES20.glGetUniformLocation(shaderPrograma, "u_Textura");
    }

    public void carregarTexturas(Context contexto) {
        texturas = new int[TipoBloco.values().length];
        GLES20.glGenTextures(texturas.length, texturas, 0);

        carregarTextura(contexto, TipoBloco.TERRA.ordinal(), R.drawable.terra);
        carregarTextura(contexto, TipoBloco.GRAMA.ordinal(), R.drawable.grama_lado);
        carregarTextura(contexto, TipoBloco.PEDRA.ordinal(), R.drawable.pedra);
        carregarTextura(contexto, TipoBloco.BEDROCK.ordinal(), R.drawable.bedrock);
    }

    private void carregarTextura(Context contexto, int index, int resId) {
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texturas[index]);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST);

        Bitmap bitmap = BitmapFactory.decodeResource(contexto.getResources(), resId);
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0);
        bitmap.recycle();
    }

    public void renderizar(float[] vpMatriz) {
        GLES20.glUseProgram(shaderPrograma);
        GLES20.glUniformMatrix4fv(lidarvPMatriz, 1, false, vpMatriz, 0);

        for(int x = 0; x < CHUNK_TAMANHO; x++) {
            for(int y = 0; y < MUNDO_LATERAL; y++) {
                for(int z = 0; z < CHUNK_TAMANHO; z++) {
                    Bloco bloco = blocos[x][y][z];
                    if(bloco.tipo != TipoBloco.AR) {
                        renderizarBloco(bloco);
                    }
                }
            }
        }
    }

    private void renderizarBloco(Bloco bloco) {
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texturas[bloco.tipo.ordinal()]);

        FloatBuffer verticesBuffer = ShaderUtils.criarBufferFloat(bloco.obterVertices());
        FloatBuffer texCoordBuffer = ShaderUtils.criarBufferFloat(bloco.obterCoordenadas());

        GLES20.glVertexAttribPointer(lidarPosicao, 3, GLES20.GL_FLOAT, false, 0, verticesBuffer);
        GLES20.glEnableVertexAttribArray(lidarPosicao);

        GLES20.glVertexAttribPointer(lidarTexCoord, 2, GLES20.GL_FLOAT, false, 0, texCoordBuffer);
        GLES20.glEnableVertexAttribArray(lidarTexCoord);

        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, bloco.obterVertices().length / 3);
    }
}
