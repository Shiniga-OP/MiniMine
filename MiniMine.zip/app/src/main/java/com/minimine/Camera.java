package com.minimine;

public class Camera {
    public float[] posicao = new float[3]; // [x, y, z]
    public float[] frente = new float[3];
    public float[] up = new float[3];
    private float yaw = -90f;
    private float tom = 0f;

    public Camera() {
        // posicao inicial
        posicao[0] = 8f;   // x
        posicao[1] = 32f;  // y
        posicao[2] = 8f;   // z

        // direcao inicial(ponto de foco)
        frente[0] = 0f;
        frente[1] = 0f;
        frente[2] = -1f;

        // vetor up
        up[0] = 0f;
        up[1] = 1f;
        up[2] = 0f;
    }

    public void rotacionar(float dx, float dy) {
        yaw += dx;
        tom -= dy;
        
        if(tom > 89f) tom = 89f;
        if(tom < -89f) tom = -89f;

        frente[0] = (float)(Math.cos(Math.toRadians(yaw)) * (float)Math.cos(Math.toRadians(tom)));
        frente[1] = (float)Math.sin(Math.toRadians(tom));
        frente[2] = (float)(Math.sin(Math.toRadians(yaw)) * (float)Math.cos(Math.toRadians(tom)));
        normalize(frente);
    }

    public void mover(float speed) {
        posicao[0] += frente[0] * speed;
        posicao[1] += frente[1] * speed;
        posicao[2] += frente[2] * speed;
    }

    public void strafe(float speed) {
        float[] right = {
            frente[2], 0f, -frente[0]
        };
        normalize(right);

        posicao[0] += right[0] * speed;
        posicao[2] += right[2] * speed;
    }

    private void normalize(float[] vec) {
        float tamanho = (float)Math.sqrt(vec[0]*vec[0] + vec[1]*vec[1] + vec[2]*vec[2]);
        if(tamanho == 0f) return;
        vec[0] /= tamanho;
        vec[1] /= tamanho;
        vec[2] /= tamanho;
    }
}
