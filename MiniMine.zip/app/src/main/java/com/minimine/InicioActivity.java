package com.minimine;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.EditText;
import java.util.Random;

public class InicioActivity extends Activity {
    
	private EditText seed;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mundo);
		
		seed = findViewById(R.id.seed);
    }
	
	public void paraJogo(View v) {
		Intent intent = new Intent(this, MundoActivity.class);
		
		if(!seed.getText().toString().equals("")) intent.putExtra("seed", Integer.parseInt(seed.getText().toString()));
		else {
			Random aleatorio = new Random();
			intent.putExtra("seed", aleatorio.nextInt(9999999));
		}
		
		startActivity(intent);
	}
}
