package com.minimine;

class Player extends Camera {
	public int saude = 20;
	public float velocidade = 0.2f;
	public float salto = 0.005f;

	public float peso = 1f;
	public float pesoTotal = 0.01f;

	public TipoBloco itemMao = TipoBloco.GRAMA;
	public float alcance = 7f;

	public Player() {
		super();
		hitbox[0] = 1.8f;
		hitbox[1] = 0.5f;
	}
}

class Camera {
    public float[] posicao = new float[3]; // [x, y, z]
    public float[] foco = new float[3];
    public float[] up = new float[3];

	public float[] hitbox = new float[2];

    public float yaw = -90f;
    public float tom = 0f;

    public Camera() {
        // posicao inicial
        posicao[0] = 8f;   // x
        posicao[1] = 40f;  // y
        posicao[2] = 8f;   // z

        // direcao inicial(ponto de foco)
        foco[0] = 0f;
        foco[1] = 0f;
        foco[2] = -1f;

        // vetor up
        up[0] = 0f;
        up[1] = 1f;
        up[2] = 0f;

		hitbox[0] = 0.5f;
		hitbox[1] = 0.5f;
    }

    public void rotacionar(float dx, float dy) {
        // rotacao invertida propositalmente para rotacao certa:
        yaw += dx;
        tom -= dy;

        if(tom > 89f) tom = 89f;
        if(tom < -89f) tom = -89f;

        foco[0] = (float)(Math.cos(Math.toRadians(yaw)) * (float)Math.cos(Math.toRadians(tom)));
        foco[1] = (float)Math.sin(Math.toRadians(tom));
        foco[2] = (float)(Math.sin(Math.toRadians(yaw)) * (float)Math.cos(Math.toRadians(tom)));
        normalize(foco);
    }

    public void mover(float velocidade) {
        posicao[0] += foco[0] * velocidade;
        posicao[1] += foco[1] * velocidade;
        posicao[2] += foco[2] * velocidade;
    }

    public void strafe(float velocidade) {
        float[] direita = {
            foco[2], 0f, -foco[0]
        };
        normalize(direita);

        // controle invertido para os controles certos
        posicao[0] -= direita[0] * velocidade;
        posicao[2] -= direita[2] * velocidade;
    }

    private void normalize(float[] vec) {
        float tamanho = (float)Math.sqrt(vec[0]*vec[0] + vec[1]*vec[1] + vec[2]*vec[2]);
        if(tamanho==0f) return;
        vec[0] /= tamanho;
        vec[1] /= tamanho;
        vec[2] /= tamanho;
    }
}
