package com.minimine;

public enum TipoBloco {
    AR,
    TERRA,
    GRAMA,
    PEDRA,
    BEDROCK;
}
