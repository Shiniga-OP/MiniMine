package com.minimine;
/*
import bsh.Interpreter;
import java.util.HashMap;
import bsh.EvalError;
import java.util.ArrayList;
*/
public class TesteEngine {
    /*
    public String importacoes;
    public Interpreter bsh;
    public ArrayList<String> nomes = new ArrayList<>();
    public HashMap<String, Object> recursos = new HashMap<>();
    
    public TesteEngine() {
        this.bsh = new Interpreter();
        
        this.importacoes =
            "import java.util.*;\n import java.io.*;\n"+
            "import android.widget.*;\n import android.opengl.*;\n import android.graphics.*;\n import android.view.*;\n import android.content.*;\n"+
            "import javax.microedition.khronos.egl.*;\n import javax.microedition.khronos.opengles.*;\n";
    }
    
    public String setarRecursos(String nomeRecurso, Object setarRecurso) {
        if(this.recursos.containsKey(nomeRecurso)) return "ja existe";
        else {
            this.recursos.put(nomeRecurso, setarRecurso);
            this.nomes.add(nomeRecurso);
            try {
                for(String nome : this.nomes) {
                    this.bsh.set(nome, this.recursos.get(nome));
                }
                return "0 erros ";
            } catch (EvalError e) {
                return "erro: "+e;
            }
        }
    }
    
    public String executar(String codigo) {
        try {
            this.bsh.eval(this.importacoes+codigo);
            return "0 erros";
        } catch (EvalError e) {
            return "erro: "+e;
        }
    } */
}
