package com.minimine;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.view.MotionEvent;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class GLRender implements GLSurfaceView.Renderer {
    private final Context contexto;
    private final float[] projecaoMatriz = new float[16];
    private final float[] viewMatriz = new float[16];
    private final float[] vpMatriz = new float[16];

    private Mundo mundo;
    private Camera camera;
    private float previsaoX, previsaoY;

    public GLRender(Context contexto) {
        this.contexto = contexto;
        this.camera = new Camera();
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(0.53f, 0.81f, 0.98f, 1.0f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glDisable(GLES20.GL_CULL_FACE);
        GLES20.glCullFace(GLES20.GL_BACK);

        this.mundo = new Mundo();
        this.mundo.initShaders(contexto);
        this.mundo.carregarTexturas(contexto);
        atualizarViewMatriz();
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int horizontal, int lateral) {
        GLES20.glViewport(0, 0, horizontal, lateral);
        float ratio = (float) horizontal / lateral;
        Matrix.perspectiveM(projecaoMatriz, 0, 90, ratio, 0.1f, 1000f);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        Matrix.multiplyMM(vpMatriz, 0, projecaoMatriz, 0, viewMatriz, 0);
        mundo.renderizar(vpMatriz);
    }

    public boolean eventoToque(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_MOVE) {
            float dx = e.getX() - previsaoX;
            float dy = e.getY() - previsaoY;

            camera.rotacionar(dx * 0.15f, dy * 0.15f);
            atualizarViewMatriz();
        }
        previsaoX = e.getX();
        previsaoY = e.getY();
        return true;
    }

    public void moverFrente() { camera.mover(0.1f); atualizarViewMatriz(); }
    public void moverTras() { camera.mover(-0.1f); atualizarViewMatriz(); }
    public void moverEsquerda() { camera.strafe(-0.1f); atualizarViewMatriz(); }
    public void moverDireita() { camera.strafe(0.1f); atualizarViewMatriz(); }

    private void atualizarViewMatriz() {
        Matrix.setLookAtM(viewMatriz, 0,
                          camera.posicao[0], camera.posicao[1], camera.posicao[2],
                          camera.posicao[0] + camera.frente[0],
                          camera.posicao[1] + camera.frente[1],
                          camera.posicao[2] + camera.frente[2],
                          camera.up[0], camera.up[1], camera.up[2]);
    }
}
