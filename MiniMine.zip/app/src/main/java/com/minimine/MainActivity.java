package com.minimine;

import android.app.Activity;

import android.os.Bundle;
import android.os.Handler;

import android.widget.Button;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import android.opengl.GLUtils;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.opengl.GLES20;

import android.content.Context;

import android.view.MotionEvent;
import android.view.MotionEvent;
import android.view.View;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import java.nio.FloatBuffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import java.io.InputStream;

public class MainActivity extends Activity {
    private GLSurfaceView tela;
    private GLRender render;

    private Handler responsavel = new Handler();
    private Runnable movimentoRepetitivo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tela = findViewById(R.id.tela);
        tela.setEGLContextClientVersion(2);

        render = new GLRender(this);
        tela.setRenderer(render);
        tela.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);

        prepararControles();
    }

    private void prepararControles() {
        final Button btnFrente = findViewById(R.id.btnFrente);
        final Button btnEsquerda = findViewById(R.id.btnEsquerda);
        final Button btnDireita = findViewById(R.id.btnDireita);
        final Button btnTras = findViewById(R.id.btnTras);

        View.OnTouchListener movimentoAgendado = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent evento) {
                switch (evento.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startMoving(v);
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        stopMoving();
                        break;
                }
                return true;
            }
        };

        btnFrente.setOnTouchListener(movimentoAgendado);
        btnEsquerda.setOnTouchListener(movimentoAgendado);
        btnDireita.setOnTouchListener(movimentoAgendado);
        btnTras.setOnTouchListener(movimentoAgendado);
    }

    private void startMoving(final View v) {
        movimentoRepetitivo = new Runnable() {
            @Override
            public void run() {
                switch (v.getId()) {
                    case R.id.btnFrente:
                        render.moverFrente();
                        break;
                    case R.id.btnEsquerda:
                        render.moverEsquerda();
                        break;
                    case R.id.btnDireita:
                        render.moverDireita();
                        break;
                    case R.id.btnTras:
                        render.moverTras();
                        break;
                }
                responsavel.postDelayed(this, 50);
            }
        };
        responsavel.post(movimentoRepetitivo);
    }

    private void stopMoving() {
        if (movimentoRepetitivo != null) {
            responsavel.removeCallbacks(movimentoRepetitivo);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        return render.eventoToque(e);
    }

    @Override
    protected void onResume() {
        super.onResume();
        tela.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        tela.onPause();
    }
}

enum TipoBloco {
    AR,
    GRAMA,
    GRAMA_LADO,
    TERRA,
    PEDRA,
    BEDROCK;
}

class Bloco {
    public int x, y, z;
    public TipoBloco tipo;

    public Bloco(int x, int y, int z, TipoBloco tipo) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.tipo = tipo;
    }

    public float[] obterVertices() {
        return new float[] {
            // face de frente
            x, y, z+1, x+1, y, z+1, x+1, y+1, z+1,
            x, y, z+1, x+1, y+1, z+1, x, y+1, z+1,

            // face de tras
            x, y, z, x+1, y, z, x+1, y+1, z,
            x, y, z, x+1, y+1, z, x, y+1, z,

            // face de cima
            x, y+1, z, x+1, y+1, z, x+1, y+1, z+1,
            x, y+1, z, x+1, y+1, z+1, x, y+1, z+1,

            // face de baixo
            x, y, z, x+1, y, z, x+1, y, z+1,
            x, y, z, x+1, y, z+1, x, y, z+1,

            // face esquerda
            x, y, z, x, y+1, z, x, y+1, z+1,
            x, y, z, x, y+1, z+1, x, y, z+1,

            // face direita
            x+1, y, z, x+1, y+1, z, x+1, y+1, z+1,
            x+1, y, z, x+1, y+1, z+1, x+1, y, z+1
        };
    }

    public float[] obterCoordenadas(String face) {
        switch(face) {
            case "frente":
                return new float[] {
                    // face de frente
                    0,1, 1,1, 1,0,
                    0,1, 1,0, 0,0,
                };
            case "tras":
                return new float[] {
                    // face de trás
                    0,1, 1,1, 1,0,
                    0,1, 1,0, 0,0,
                };
            case "cima":
                return new float[] {
                    // face de cima
                    0,1, 1,1, 1,0,
                    0,1, 1,0, 0,0,
                };
            case "baixo":
                return new float[] {
                    // face de baixo
                    0,1, 1,1, 1,0,
                    0,1, 1,0, 0,0,
                };
            case "esquerda":
                return new float[] {
                    // face esquerda
                    0,1, 0,0, 1,0,
                    0,1, 1,0, 1,1,
                };
            case "direita":
                return new float[] {
                    // face direita
                    0,1, 0,0, 1,0,
                    0,1, 1,0, 1,1
                };
            case "todas":
                return new float[] {
                    // face de frente
                    0,1, 1,1, 1,0,
                    0,1, 1,0, 0,0,
                    // face de trás
                    0,1, 1,1, 1,0,
                    0,1, 1,0, 0,0,
                    //face de cima
                    0,1, 1,1, 1,0,
                    0,1, 1,0, 0,0,
                    //face de baixo
                    0,1, 1,1, 1,0,
                    0,1, 1,0, 0,0,
                    //face esquerda
                    0,1, 0,0, 1,0,
                    0,1, 1,0, 1,1,
                    //face direita
                    0,1, 0,0, 1,0,
                    0,1, 1,0, 1,1
                };
            default:
                return new float[]{};
        }
    }
}

class Mundo {
    private static final int CHUNK_TAMANHO = 16;
    private static final int MUNDO_LATERAL = 32;

    private Bloco[][][] blocos;
    private int[] texturas;
    private int shaderPrograma;
    private int lidarvPMatriz;
    private int lidarPosicao;
    private int lidarTexCoord;
    private int lidarTexturas;

    public Mundo() {
        gerarMundo();
    }

    private void gerarMundo() {
        blocos = new Bloco[CHUNK_TAMANHO][MUNDO_LATERAL][CHUNK_TAMANHO];

        for(int x = 0; x < CHUNK_TAMANHO; x++) {
            for(int z = 0; z < CHUNK_TAMANHO; z++) {
                float valorNoise = PerlinNoise.ruido(x/10f, z/10f);
                int lateral = (int)(valorNoise * 10 + 32);

                for(int y = 0; y < MUNDO_LATERAL; y++) {
                    TipoBloco tipo = TipoBloco.AR;

                    if(y == 0) {
                        tipo = TipoBloco.BEDROCK;
                    } else if(y < lateral - 4) {
                        tipo = TipoBloco.PEDRA;
                    } else if(y < lateral) {
                        tipo = TipoBloco.TERRA;
                    } else if(y == lateral) {
                        tipo = TipoBloco.GRAMA_LADO;
                    }
                    blocos[x][y][z] = new Bloco(x, y, z, tipo);
                }
            }
        }
    }

    public void iniciarShaders(Context contexto) {
        String verticesShader = ShaderUtils.lerShaderDoRaw(contexto, R.raw.vertices_shader);
        String fragmentoShader = ShaderUtils.lerShaderDoRaw(contexto, R.raw.fragmento_shader);
        shaderPrograma = ShaderUtils.criarPrograma(verticesShader, fragmentoShader);

        lidarvPMatriz = GLES20.glGetUniformLocation(shaderPrograma, "u_VPMatriz");
        lidarPosicao = GLES20.glGetAttribLocation(shaderPrograma, "a_Posicao");
        lidarTexCoord = GLES20.glGetAttribLocation(shaderPrograma, "a_TexCoord");
        lidarTexturas = GLES20.glGetUniformLocation(shaderPrograma, "u_Textura");
    }

    public void carregarTexturas(Context contexto) {
        texturas = new int[TipoBloco.values().length];
        GLES20.glGenTextures(texturas.length, texturas, 0);

        carregarTextura(contexto, TipoBloco.TERRA.ordinal(), R.drawable.terra);
        carregarTextura(contexto, TipoBloco.GRAMA.ordinal(), R.drawable.grama_cima);
        carregarTextura(contexto, TipoBloco.GRAMA_LADO.ordinal(), R.drawable.grama_lado);
        carregarTextura(contexto, TipoBloco.PEDRA.ordinal(), R.drawable.pedra);
        carregarTextura(contexto, TipoBloco.BEDROCK.ordinal(), R.drawable.bedrock);
    }

    private void carregarTextura(Context contexto, int index, int resId) {
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texturas[index]);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST);

        Bitmap bitmap = BitmapFactory.decodeResource(contexto.getResources(), resId);
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0);
        bitmap.recycle();
    }

    public void renderizar(float[] vpMatriz) {
        GLES20.glUseProgram(shaderPrograma);
        GLES20.glUniformMatrix4fv(lidarvPMatriz, 1, false, vpMatriz, 0);

        for(int x = 0; x < CHUNK_TAMANHO; x++) {
            for(int y = 0; y < MUNDO_LATERAL; y++) {
                for(int z = 0; z < CHUNK_TAMANHO; z++) {
                    Bloco bloco = blocos[x][y][z];
                    if(bloco.tipo != TipoBloco.AR) {
                        renderizarBloco(bloco);
                    }
                }
            }
        }
    }

    private void renderizarBloco(Bloco bloco) {
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texturas[bloco.tipo.ordinal()]);

        FloatBuffer verticesBuffer = ShaderUtils.criarBufferFloat(bloco.obterVertices());
        FloatBuffer texCoordBuffer = ShaderUtils.criarBufferFloat(bloco.obterCoordenadas("todas"));

        GLES20.glVertexAttribPointer(lidarPosicao, 3, GLES20.GL_FLOAT, false, 0, verticesBuffer);
        GLES20.glEnableVertexAttribArray(lidarPosicao);

        GLES20.glVertexAttribPointer(lidarTexCoord, 2, GLES20.GL_FLOAT, false, 0, texCoordBuffer);
        GLES20.glEnableVertexAttribArray(lidarTexCoord);

        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, bloco.obterVertices().length / 3);
    }
}

class GLRender implements GLSurfaceView.Renderer {
        private final Context contexto;
        private final float[] projecaoMatriz = new float[16];
        private final float[] viewMatriz = new float[16];
        private final float[] vpMatriz = new float[16];

        private Mundo mundo;
        private Camera camera;
        private float previsaoX, previsaoY;

        public GLRender(Context contexto) {
            this.contexto = contexto;
            this.camera = new Camera();
        }

        @Override
        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            GLES20.glClearColor(0.53f, 0.81f, 0.98f, 1.0f);
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);
            GLES20.glDisable(GLES20.GL_CULL_FACE);
            GLES20.glCullFace(GLES20.GL_BACK);

            this.mundo = new Mundo();
            this.mundo.iniciarShaders(contexto);
            this.mundo.carregarTexturas(contexto);
            atualizarViewMatriz();
        }

        @Override
        public void onSurfaceChanged(GL10 gl, int horizontal, int lateral) {
            GLES20.glViewport(0, 0, horizontal, lateral);
            float ratio = (float) horizontal / lateral;
            Matrix.perspectiveM(projecaoMatriz, 0, 90, ratio, 0.1f, 1000f);
        }

        @Override
        public void onDrawFrame(GL10 gl) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
            Matrix.multiplyMM(vpMatriz, 0, projecaoMatriz, 0, viewMatriz, 0);
            mundo.renderizar(vpMatriz);
        }

        public boolean eventoToque(MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_MOVE) {
                float dx = e.getX() - previsaoX;
                float dy = e.getY() - previsaoY;

                camera.rotacionar(dx * 0.15f, dy * 0.15f);
                atualizarViewMatriz();
            }
            previsaoX = e.getX();
            previsaoY = e.getY();
            return true;
        }

        public void moverFrente() { camera.mover(0.1f); atualizarViewMatriz(); }
        public void moverTras() { camera.mover(-0.1f); atualizarViewMatriz(); }
        public void moverEsquerda() { camera.strafe(-0.1f); atualizarViewMatriz(); }
        public void moverDireita() { camera.strafe(0.1f); atualizarViewMatriz(); }

        private void atualizarViewMatriz() {
            Matrix.setLookAtM(viewMatriz, 0,
                              camera.posicao[0], camera.posicao[1], camera.posicao[2],
                              camera.posicao[0] + camera.frente[0],
                              camera.posicao[1] + camera.frente[1],
                              camera.posicao[2] + camera.frente[2],
                              camera.up[0], camera.up[1], camera.up[2]);
        }
    }
    
class ShaderUtils {
    public static int carregarShader(int tipo, String shaderCodigo) {
        int shader = GLES20.glCreateShader(tipo);
        GLES20.glShaderSource(shader, shaderCodigo);
        GLES20.glCompileShader(shader);
        return shader;
    }

    public static int criarPrograma(String shaderVerticesCodigo, String shaderFragmentoCodigo) {
        int verticesShader = carregarShader(GLES20.GL_VERTEX_SHADER, shaderVerticesCodigo);
        int fragmentoShader = carregarShader(GLES20.GL_FRAGMENT_SHADER, shaderFragmentoCodigo);

        int programa = GLES20.glCreateProgram();
        GLES20.glAttachShader(programa, verticesShader);
        GLES20.glAttachShader(programa, fragmentoShader);
        GLES20.glLinkProgram(programa);
        return programa;
    }

    public static FloatBuffer criarBufferFloat(float[] dados) {
        ByteBuffer bb = ByteBuffer.allocateDirect(dados.length * 4);
        bb.order(ByteOrder.nativeOrder());
        FloatBuffer fb = bb.asFloatBuffer();
        fb.put(dados);
        fb.position(0);
        return fb;
    }

    public static String lerShaderDoRaw(Context contexto, int resId) {
        try {
            InputStream is = contexto.getResources().openRawResource(resId);
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            return new String(buffer);
        } catch (Exception e) {
            return null;
        }
    }
}

class Camera {
    public float[] posicao = new float[3]; // [x, y, z]
    public float[] frente = new float[3];
    public float[] up = new float[3];
    private float yaw = -90f;
    private float tom = 0f;

    public Camera() {
        // posicao inicial
        posicao[0] = 8f;   // x
        posicao[1] = 32f;  // y
        posicao[2] = 8f;   // z

        // direcao inicial(ponto de foco)
        frente[0] = 0f;
        frente[1] = 0f;
        frente[2] = -1f;

        // vetor up
        up[0] = 0f;
        up[1] = 1f;
        up[2] = 0f;
    }

    public void rotacionar(float dx, float dy) {
        yaw += dx;
        tom -= dy;

        if(tom > 89f) tom = 89f;
        if(tom < -89f) tom = -89f;

        frente[0] = (float)(Math.cos(Math.toRadians(yaw)) * (float)Math.cos(Math.toRadians(tom)));
        frente[1] = (float)Math.sin(Math.toRadians(tom));
        frente[2] = (float)(Math.sin(Math.toRadians(yaw)) * (float)Math.cos(Math.toRadians(tom)));
        normalize(frente);
    }

    public void mover(float velocidade) {
        posicao[0] += frente[0] * velocidade;
        posicao[1] += frente[1] * velocidade;
        posicao[2] += frente[2] * velocidade;
    }

    public void strafe(float speed) {
        float[] direita = {
            frente[2], 0f, -frente[0]
        };
        normalize(direita);

        posicao[0] -= direita[0] * speed;
        posicao[2] -= direita[2] * speed;
    }

    private void normalize(float[] vec) {
        float tamanho = (float)Math.sqrt(vec[0]*vec[0] + vec[1]*vec[1] + vec[2]*vec[2]);
        if(tamanho == 0f) return;
        vec[0] /= tamanho;
        vec[1] /= tamanho;
        vec[2] /= tamanho;
    }
}
