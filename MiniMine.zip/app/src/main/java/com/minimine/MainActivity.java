package com.minimine;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.opengl.GLSurfaceView;
import android.os.Handler;

public class MainActivity extends Activity {
    private GLSurfaceView tela;
    private GLRender render;

    private Handler responsavel = new Handler();
    private Runnable movimentoRepetitivo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tela = findViewById(R.id.tela);
        tela.setEGLContextClientVersion(2);

        render = new GLRender(this);
        tela.setRenderer(render);
        tela.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);

        prepararControles();
    }

    private void prepararControles() {
        final Button btnFrente = findViewById(R.id.btnFrente);
        final Button btnEsquerda = findViewById(R.id.btnEsquerda);
        final Button btnDireita = findViewById(R.id.btnDireita);
        final Button btnTras = findViewById(R.id.btnTras);

        View.OnTouchListener movimentoAgendado = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent evento) {
                switch (evento.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startMoving(v);
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        stopMoving();
                        break;
                }
                return true;
            }
        };

        btnFrente.setOnTouchListener(movimentoAgendado);
        btnEsquerda.setOnTouchListener(movimentoAgendado);
        btnDireita.setOnTouchListener(movimentoAgendado);
        btnTras.setOnTouchListener(movimentoAgendado);
    }

    private void startMoving(final View v) {
        movimentoRepetitivo = new Runnable() {
            @Override
            public void run() {
                switch (v.getId()) {
                    case R.id.btnFrente:
                        render.moverFrente();
                        break;
                    case R.id.btnEsquerda:
                        render.moverEsquerda();
                        break;
                    case R.id.btnDireita:
                        render.moverDireita();
                        break;
                    case R.id.btnTras:
                        render.moverTras();
                        break;
                }
                responsavel.postDelayed(this, 50);
            }
        };
        responsavel.post(movimentoRepetitivo);
    }

    private void stopMoving() {
        if (movimentoRepetitivo != null) {
            responsavel.removeCallbacks(movimentoRepetitivo);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        return render.eventoToque(e);
    }

    @Override
    protected void onResume() {
        super.onResume();
        tela.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        tela.onPause();
    }
}
