package com.minimine;

import android.app.Activity;

import android.os.Bundle;
import android.os.Handler;

import android.widget.Button;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import android.opengl.GLUtils;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.opengl.GLES20;

import android.content.Context;

import android.view.MotionEvent;
import android.view.MotionEvent;
import android.view.View;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import java.nio.FloatBuffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* 
O codigo atual é protegido por uma licença.

o codigo pode ser utilizado de todas as formas dentro das restrições a seguir:

-Não se pode alterar o idioma original do codigo, ou seja, portugues.
-Qualquer alteração no codigo e, quaisquer danos ou utilidades que dê a esse codigo, são responsabilidade totalmente sua.
-Não estamos associados ao que você fará a seguir com o codigo, então não deixe marcas ou indentificações que sejam originais do codigo.

qualquer alteracao, utilizacao ou adicao ao codigo deve respeitar as regras, juntamente da natividade do idioma original do codigo atual.

faça bom uso.
*/

// verificacoes podem afetar a performace, Log.e é inutil, ja que no android, esses logs so sao exibidos crashando a aplicacao 2 vezes seguidas

public class MainActivity extends Activity {
    private GLSurfaceView tela;
    private GLRender render;

    private Handler responsavel = new Handler();
    private Runnable movimentoRepetitivo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tela = findViewById(R.id.tela);
        tela.setEGLContextClientVersion(2);

        render = new GLRender(this);
        tela.setRenderer(render);
        tela.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        prepararControles();
    }

    private void prepararControles() {
        final Button btnFrente = findViewById(R.id.btnFrente);
        final Button btnEsquerda = findViewById(R.id.btnEsquerda);
        final Button btnDireita = findViewById(R.id.btnDireita);
        final Button btnTras = findViewById(R.id.btnTras);

        View.OnTouchListener movimentoAgendado = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent evento) {
                switch (evento.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        moviComecar(v);
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        moviParar();
                        break;
                }
                return true;
            }
        };

        btnFrente.setOnTouchListener(movimentoAgendado);
        btnEsquerda.setOnTouchListener(movimentoAgendado);
        btnDireita.setOnTouchListener(movimentoAgendado);
        btnTras.setOnTouchListener(movimentoAgendado);
    }

    private void moviComecar(final View v) {
        movimentoRepetitivo = new Runnable() {
            @Override
            public void run() {
                switch (v.getId()) {
                    case R.id.btnFrente:
                        render.moverFrente();
                        break;
                    case R.id.btnEsquerda:
                        render.moverEsquerda();
                        break;
                    case R.id.btnDireita:
                        render.moverDireita();
                        break;
                    case R.id.btnTras:
                        render.moverTras();
                        break;
                }
                responsavel.postDelayed(this, 50);
            }
        };
        responsavel.post(movimentoRepetitivo);
    }

    private void moviParar() {
        if (movimentoRepetitivo != null) {
            responsavel.removeCallbacks(movimentoRepetitivo);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        return render.eventoToque(e);
    }

    @Override
    protected void onResume() {
        super.onResume();
        tela.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        render.mundo.limparTexturas();
        tela.onPause();
    }
}

enum TipoBloco {
    AR(),
    // grama tem 6 texturas, cada bloco tem 6 texturas mesmo iguais, caso nao especifcadas, nao renderizadas
    GRAMA(R.drawable.grama_lado, R.drawable.grama_lado, R.drawable.grama_cima, R.drawable.terra, R.drawable.grama_lado2, R.drawable.grama_lado2),
    TERRA(R.drawable.terra, R.drawable.terra, R.drawable.terra, R.drawable.terra, R.drawable.terra, R.drawable.terra),
    PEDRA(R.drawable.pedra, R.drawable.pedra, R.drawable.pedra, R.drawable.pedra, R.drawable.pedra, R.drawable.pedra),
    BEDROCK(R.drawable.bedrock, R.drawable.bedrock, R.drawable.bedrock, R.drawable.bedrock, R.drawable.bedrock, R.drawable.bedrock);

    private final int[] recursosTexturas;

    TipoBloco(int... recursos) {
        this.recursosTexturas = recursos;
    }

    public int obterRecursoTextura(int face) {
        if(recursosTexturas == null || face < 0 || face >= recursosTexturas.length) 
            return -1;
        return recursosTexturas[face];
    }
    
    public boolean eSolido() {
        return this != AR; // blocos solidos não são AR
    }
}

class Bloco {
    public int x, y, z;
    public TipoBloco tipo;

    public Bloco(int x, int y, int z, TipoBloco tipo) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.tipo = tipo;
    }

    public float[] obterVertices() {
        return new float[] {
            // face de frente
            x, y, z+1, x+1, y, z+1, x+1, y+1, z+1,
            x, y, z+1, x+1, y+1, z+1, x, y+1, z+1,

            // face de tras
            x, y, z, x+1, y, z, x+1, y+1, z,
            x, y, z, x+1, y+1, z, x, y+1, z,

            // face de cima
            x, y+1, z, x+1, y+1, z, x+1, y+1, z+1,
            x, y+1, z, x+1, y+1, z+1, x, y+1, z+1,

            // face de baixo
            x, y, z, x+1, y, z, x+1, y, z+1,
            x, y, z, x+1, y, z+1, x, y, z+1,

            // face esquerda
            x, y, z, x, y+1, z, x, y+1, z+1,
            x, y, z, x, y+1, z+1, x, y, z+1,

            // face direita
            x+1, y, z, x+1, y+1, z, x+1, y+1, z+1,
            x+1, y, z, x+1, y+1, z+1, x+1, y, z+1
        };
    }
    public float[] obterCoordenadas() {
        // 6 faces, 6 vertices por face, 2 coordenadas UV cada
        float[] coordenadas = new float[6 * 6 * 2];

        // preenche todas as faces com coordenadas 0-1 por padrao
        for(int i = 0; i < coordenadas.length; i += 12) {
            // primeiro triangulo
            coordenadas[i] = 0; coordenadas[i+1] = 1;  // vertice 1
            coordenadas[i+2] = 1; coordenadas[i+3] = 1; // vertice 2
            coordenadas[i+4] = 1; coordenadas[i+5] = 0; // vertice 3
            // segundo triangulo
            coordenadas[i+6] = 0; coordenadas[i+7] = 1; // vertice 1
            coordenadas[i+8] = 1; coordenadas[i+9] = 0; // vertice 3
            coordenadas[i+10] = 0; coordenadas[i+11] = 0; // vertice 4
        }
        return coordenadas;
    }
}

class Mundo {
    public static final int CHUNK_TAMANHO = 8; // padrao: 16, testes: 8
    private static final int MUNDO_LATERAL = 16; // padrao: 60, testes: 16
    private static final int RAIO_CARREGAMENTO = 2; // padrao: 3, testes: 2
    
    private static final int FACES_POR_BLOCO = 6;

    private int shaderPrograma;
    private int lidarvPMatriz;
    private int lidarPosicao;
    private int lidarTexCoord;
    private int lidarTexturas;
    private HashMap<TipoBloco, int[]> texturasBlocos = new HashMap<>();
    
    private HashMap<String, Bloco[][][]> chunksAtivos = new HashMap<>();
    private HashMap<String, Bloco[][][]> chunksCarregados = new HashMap<>();

        public void atualizarChunks(float posX, float posZ) {
            int chunkJogadorX = (int) Math.floor(posX / CHUNK_TAMANHO);
            int chunkJogadorZ = (int) Math.floor(posZ / CHUNK_TAMANHO);

            // descarregar chunks fora do raio
            Iterator<Map.Entry<String, Bloco[][][]>> iterator = chunksAtivos.entrySet().iterator();
            while(iterator.hasNext()) {
                Map.Entry<String, Bloco[][][]> entry = iterator.next();
                String[] coordenadas = entry.getKey().split(",");
                int chunkX = Integer.parseInt(coordenadas[0]);
                int chunkZ = Integer.parseInt(coordenadas[1]);

                if(Math.abs(chunkX - chunkJogadorX) > RAIO_CARREGAMENTO || 
                    Math.abs(chunkZ - chunkJogadorZ) > RAIO_CARREGAMENTO) {
                    iterator.remove();
                }
            }
            
            // carrega novos chunks
            for(int x = chunkJogadorX - RAIO_CARREGAMENTO; x <= chunkJogadorX + RAIO_CARREGAMENTO; x++) {
                for(int z = chunkJogadorZ - RAIO_CARREGAMENTO; z <= chunkJogadorZ + RAIO_CARREGAMENTO; z++) {
                    String chave = x + "," + z;
                    if(!chunksAtivos.containsKey(chave)) {
                        chunksAtivos.put(chave, carregarChunk(x, z));
                    }
                }
            }
        }
        
    // gera ou carrega chunks ja existentes
    private Bloco[][][] carregarChunk(int chunkX, int chunkY) {
        String chave = chunkX + "," + chunkY;
        if(chunksCarregados.containsKey(chave)) {
            return chunksCarregados.get(chave);
        }
        else {
            Bloco[][][] chunk = gerarChunk(chunkX, chunkY);
            chunksCarregados.put(chave, chunk);
            return chunk;
        }
    }

        // gera um chunk especifico
        private Bloco[][][] gerarChunk(int chunkX, int chunkZ) {
            Bloco[][][] chunk = new Bloco[CHUNK_TAMANHO][MUNDO_LATERAL][CHUNK_TAMANHO];
            for(int x = 0; x < CHUNK_TAMANHO; x++) {
                for(int z = 0; z < CHUNK_TAMANHO; z++) {
                    // converter para coordenadas globais
                    int globalX = chunkX * CHUNK_TAMANHO + x;
                    int globalZ = chunkZ * CHUNK_TAMANHO + z;

                    // gerar terreno(codigo original adaptado)
                    float valorNoise = PerlinNoise.ruido(globalX / 10f, globalZ / 10f);
                    int lateral = (int)(valorNoise * 10 + 8);

                    for(int y = 0; y < MUNDO_LATERAL; y++) {
                        TipoBloco tipo = TipoBloco.AR;
                        if(y == 0) tipo = TipoBloco.BEDROCK;
                        else if(y < lateral - 1) tipo = TipoBloco.PEDRA;
                        else if(y < lateral) tipo = TipoBloco.TERRA;
                        else if(y == lateral) tipo = TipoBloco.GRAMA;

                        chunk[x][y][z] = new Bloco(globalX, y, globalZ, tipo);
                    }
                }
            }
            return chunk;
        }
        
        public void renderizar(float[] vpMatriz) {
            GLES20.glUseProgram(shaderPrograma);
            GLES20.glUniformMatrix4fv(lidarvPMatriz, 1, false, vpMatriz, 0);

            for(Bloco[][][] chunk : chunksAtivos.values()) {
                for(int x = 0; x < CHUNK_TAMANHO; x++) {
                    for(int y = 0; y < MUNDO_LATERAL; y++) {
                        for(int z = 0; z < CHUNK_TAMANHO; z++) {
                            Bloco bloco = chunk[x][y][z];
                            if(bloco.tipo != TipoBloco.AR) {
                                renderizarBloco(bloco);
                            }
                        }
                    }
                }
            }
        }

        private boolean faceVisivel(int x, int y, int z, int face) {
            int dx = 0, dy = 0, dz = 0;
            switch(face) {
                case 0: dz = 1; break;  // frente
                case 1: dz = -1; break; // tras
                case 2: dy = 1; break;  // cima
                case 3: dy = -1; break; // baixo
                case 4: dx = -1; break; // esquerda
                case 5: dx = 1; break;  // direita
            }

            int nx = x + dx, ny = y + dy, nz = z + dz;
            String chaveChunk = (int) Math.floor(nx / (float) CHUNK_TAMANHO) + "," + (int) Math.floor(nz / (float) CHUNK_TAMANHO);

            // verificar se o chunk vizinho esta carregado
            if(!chunksAtivos.containsKey(chaveChunk)) return true;

            Bloco[][][] chunkVizinho = chunksAtivos.get(chaveChunk);
            int localX = nx % CHUNK_TAMANHO;
            int localZ = nz % CHUNK_TAMANHO;
            if(localX < 0) localX += CHUNK_TAMANHO;
            if(localZ < 0) localZ += CHUNK_TAMANHO;

            // verificar se o bloco vizinho e transparente
            if(ny < 0 || ny >= MUNDO_LATERAL) return true;
            Bloco vizinho = chunkVizinho[localX][ny][localZ];
            return vizinho.tipo == TipoBloco.AR || !vizinho.tipo.eSolido();
        }

    public void iniciarShaders(Context contexto) {
        String verticesShader = 
            "uniform mat4 u_VPMatriz;" +
            "attribute vec4 a_Posicao;" +
            "attribute vec2 a_TexCoord;" +
            "varying vec2 v_TexCoord;" +
            "void main() {" +
            "    gl_Position = u_VPMatriz * a_Posicao;" +
            "    v_TexCoord = a_TexCoord;" +
            "}";

        String fragmentoShader = 
            "precision mediump float;" +
            "varying vec2 v_TexCoord;" +
            "uniform sampler2D u_Textura;" +
            "void main() {" +
            "    gl_FragColor = texture2D(u_Textura, v_TexCoord);" +
            "}";

        shaderPrograma = ShaderUtils.criarPrograma(verticesShader, fragmentoShader);
        lidarvPMatriz = GLES20.glGetUniformLocation(shaderPrograma, "u_VPMatriz");
        lidarPosicao = GLES20.glGetAttribLocation(shaderPrograma, "a_Posicao");
        lidarTexCoord = GLES20.glGetAttribLocation(shaderPrograma, "a_TexCoord");
        lidarTexturas = GLES20.glGetUniformLocation(shaderPrograma, "u_Textura");
    }

    public void carregarTexturas(Context contexto) {
        for(TipoBloco tipo : TipoBloco.values()) {
            if(tipo==TipoBloco.AR) continue;

            int[] texturasFace = new int[FACES_POR_BLOCO];
            GLES20.glGenTextures(FACES_POR_BLOCO, texturasFace, 0);

            for(int face = 0; face < FACES_POR_BLOCO; face++) {
                int recurso = tipo.obterRecursoTextura(face);
                if(recurso==-1) continue;

                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texturasFace[face]);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST);

                Bitmap bitmap = BitmapFactory.decodeResource(contexto.getResources(), recurso);
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0);
                bitmap.recycle();
            }
            texturasBlocos.put(tipo, texturasFace);
        }
    }

    // buffers temporários reutilizados para cada face (6 vértices: 6*3 floats para vértices e 6*2 floats para texturas)
    private final FloatBuffer bufferVertices = ByteBuffer.allocateDirect(6 * 3 * 4)
    .order(ByteOrder.nativeOrder())
    .asFloatBuffer();

    private final FloatBuffer bufferTexturas = ByteBuffer.allocateDirect(6 * 2 * 4)
    .order(ByteOrder.nativeOrder())
    .asFloatBuffer();
    
    private void renderizarBloco(Bloco bloco) {
        int[] texturas = texturasBlocos.get(bloco.tipo);
        if(texturas == null) return;

        float[] vertices = bloco.obterVertices();
        float[] texCoords = bloco.obterCoordenadas();
        
        int x = bloco.x, y = bloco.y, z = bloco.z;
        
        for (int face = 0; face < 6; face++) {
            if(!faceVisivel(x, y, z, face)) continue;
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texturas[face]);

            // cada face possui 6 vértices (6*3 floats) e 6 vertices (6*2 floats de UV)
            int vertexOffset = face * 18;  // 18 = 6 vertices x 3 componentes
            int texOffset = face * 12;     // 12 = 6 vertices x 2 componentes

            bufferVertices.clear();
            bufferVertices.put(vertices, vertexOffset, 18).position(0);

            bufferTexturas.clear();
            bufferTexturas.put(texCoords, texOffset, 12).position(0);

            GLES20.glVertexAttribPointer(lidarPosicao, 3, GLES20.GL_FLOAT, false, 0, bufferVertices);
            GLES20.glEnableVertexAttribArray(lidarPosicao);

            GLES20.glVertexAttribPointer(lidarTexCoord, 2, GLES20.GL_FLOAT, false, 0, bufferTexturas);
            GLES20.glEnableVertexAttribArray(lidarTexCoord);

            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
        }
    }
    
    public void limparTexturas() {
        for (int[] ids : texturasBlocos.values()) {
            GLES20.glDeleteTextures(ids.length, ids, 0);
        }
    }
}

class GLRender implements GLSurfaceView.Renderer {
        private final Context contexto;
        private final float[] projecaoMatriz = new float[16];
        private final float[] viewMatriz = new float[16];
        private final float[] vpMatriz = new float[16];

        public Mundo mundo;
        private Camera camera;
        private float previsaoX, previsaoY;
        
        private int pax;
        private int paz;

        public GLRender(Context contexto) {
            this.contexto = contexto;
            this.camera = new Camera();
        }

        @Override
        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            GLES20.glClearColor(0.53f, 0.81f, 0.98f, 1.0f);
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);

            this.mundo = new Mundo();
            this.mundo.iniciarShaders(contexto);
            this.mundo.carregarTexturas(contexto);
            atualizarViewMatriz();
        }

        @Override
        public void onSurfaceChanged(GL10 gl, int horizontal, int lateral) {
            GLES20.glViewport(0, 0, horizontal, lateral);
            float ratio = (float) horizontal / lateral;
            Matrix.perspectiveM(projecaoMatriz, 0, 90, ratio, 0.1f, 1000f);
        }

        @Override
        public void onDrawFrame(GL10 gl) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
            
            if(pax != camera.posicao[0] || paz != camera.posicao[2])  mundo.atualizarChunks(camera.posicao[0], camera.posicao[2]);
            
            pax = (int) camera.posicao[0];
            paz = (int) camera.posicao[2];
            
            Matrix.multiplyMM(vpMatriz, 0, projecaoMatriz, 0, viewMatriz, 0);
            mundo.renderizar(vpMatriz);
        }

        public boolean eventoToque(MotionEvent e) {
            if(e.getAction()==MotionEvent.ACTION_MOVE) {
                float dx = e.getX() - previsaoX;
                float dy = e.getY() - previsaoY;

                camera.rotacionar(dx * 0.15f, dy * 0.15f);
                atualizarViewMatriz();
            }
            previsaoX = e.getX();
            previsaoY = e.getY();
            return true;
        }

        public void moverFrente() { camera.mover(0.5f); atualizarViewMatriz(); }
        public void moverTras() { camera.mover(-0.5f); atualizarViewMatriz(); }
        public void moverEsquerda() { camera.strafe(-0.5f); atualizarViewMatriz(); }
        public void moverDireita() { camera.strafe(0.5f); atualizarViewMatriz(); }

        private void atualizarViewMatriz() {
            Matrix.setLookAtM(viewMatriz, 0,
                              camera.posicao[0], camera.posicao[1], camera.posicao[2],
                              camera.posicao[0] + camera.foco[0],
                              camera.posicao[1] + camera.foco[1],
                              camera.posicao[2] + camera.foco[2],
                              camera.up[0], camera.up[1], camera.up[2]);
        }
    }
    
class ShaderUtils {
    public static int carregarShader(int tipo, String shaderCodigo) {
        int shader = GLES20.glCreateShader(tipo);
        GLES20.glShaderSource(shader, shaderCodigo);
        GLES20.glCompileShader(shader);
        return shader;
    }

    public static int criarPrograma(String shaderVerticesCodigo, String shaderFragmentoCodigo) {
        int verticesShader = carregarShader(GLES20.GL_VERTEX_SHADER, shaderVerticesCodigo);
        int fragmentoShader = carregarShader(GLES20.GL_FRAGMENT_SHADER, shaderFragmentoCodigo);

        int programa = GLES20.glCreateProgram();
        GLES20.glAttachShader(programa, verticesShader);
        GLES20.glAttachShader(programa, fragmentoShader);
        GLES20.glLinkProgram(programa);
        return programa;
    }

    public static FloatBuffer criarBufferFloat(float[] dados) {
        ByteBuffer bb = ByteBuffer.allocateDirect(dados.length * 4);
        bb.order(ByteOrder.nativeOrder());
        FloatBuffer fb = bb.asFloatBuffer();
        fb.put(dados);
        fb.position(0);
        return fb;
    }

    public static String lerShaderDoRaw(Context contexto, int resId) {
        try {
            InputStream is = contexto.getResources().openRawResource(resId);
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            return new String(buffer);
        } catch(Exception e) {
            return null;
        }
    }
}

class Camera {
    public float[] posicao = new float[3]; // [x, y, z]
    public float[] foco = new float[3];
    public float[] up = new float[3];
    private float yaw = -90f;
    private float tom = 0f;

    public Camera() {
        // posicao inicial
        posicao[0] = 8f;   // x
        posicao[1] = 16f;  // y
        posicao[2] = 8f;   // z

        // direcao inicial(ponto de foco)
        foco[0] = 0f;
        foco[1] = 0f;
        foco[2] = -1f;

        // vetor up
        up[0] = 0f;
        up[1] = 1f;
        up[2] = 0f;
    }

    public void rotacionar(float dx, float dy) {
        // rotacao invertida propositalmente para rotacao certa:
        yaw += dx;
        tom -= dy;

        if(tom > 89f) tom = 89f;
        if(tom < -89f) tom = -89f;

        foco[0] = (float)(Math.cos(Math.toRadians(yaw)) * (float)Math.cos(Math.toRadians(tom)));
        foco[1] = (float)Math.sin(Math.toRadians(tom));
        foco[2] = (float)(Math.sin(Math.toRadians(yaw)) * (float)Math.cos(Math.toRadians(tom)));
        normalize(foco);
    }

    public void mover(float velocidade) {
        posicao[0] += foco[0] * velocidade;
        posicao[1] += foco[1] * velocidade;
        posicao[2] += foco[2] * velocidade;
    }

    public void strafe(float velocidade) {
        float[] direita = {
            foco[2], 0f, -foco[0]
        };
        normalize(direita);
        
        // controle invertido para os controles certos
        posicao[0] -= direita[0] * velocidade;
        posicao[2] -= direita[2] * velocidade;
    }

    private void normalize(float[] vec) {
        float tamanho = (float)Math.sqrt(vec[0]*vec[0] + vec[1]*vec[1] + vec[2]*vec[2]);
        if(tamanho==0f) return;
        vec[0] /= tamanho;
        vec[1] /= tamanho;
        vec[2] /= tamanho;
    }
}

// gerado por IA:
class PerlinNoise {
    // simples ruido Perlin 2D
    public static float ruido(float x, float z) {
        int X = ((int) x) & 255;
        int Z = ((int) z) & 255;
        x -= (int) x;
        z -= (int) z;

        float u = fade(x), v = fade(z);

        int A = p[X] + Z, B = p[X + 1] + Z;

        return lerp(v, lerp(u, grad(p[A], x, z, 0),
                            grad(p[B], x - 1, z, 0)),
                    lerp(u, grad(p[A + 1], x, z - 1, 0),
                         grad(p[B + 1], x - 1, z - 1, 0)));
    }

    private static float fade(float t) { 
        return t * t * t * (t * (t * 6 - 15) + 10); 
    }

    private static float lerp(float t, float a, float b) { 
        return a + t * (b - a); 
    }

    private static float grad(int hash, float x, float y, float z) {
        int h = hash & 15;
        float u = h < 8 ? x : y;
        float v = h < 4 ? y : h == 12 || h == 14 ? x : z;
        return ((h & 1) == 0 ? u : -u) + ((h & 2) == 0 ? v : -v);
    }

    private static final int[] p = new int[512];
    static {
        int[] permutation = { 151,160,137,91,90,15, 
            131,13,201,95,96,53,194,233,7,225,140,36,103,30,69,142,8,99,37,240,21,10,23,
            190, 6,148,247,120,234,75,0,26,197,62,94,252,219,203,117,35,11,32,57,177,33,
            88,237,149,56,87,174,20,125,136,171,168, 68,175,74,165,71,134,139,48,27,166,
            77,146,158,231,83,111,229,122,60,211,133,230,220,105,92,41,55,46,245,40,244,
            102,143,54, 65,25,63,161, 1,216,80,73,209,76,132,187,208, 89,18,169,200,196,
            135,130,116,188,159,86,164,100,109,198,173,186, 3,64,52,217,226,250,124,123,
            5,202,38,147,118,126,255,82,85,212,207,206,59,227,47,16,58,17,182,189,28,42,
            223,183,170,213,119,248,152, 2,44,154,163, 70,221,153,101,155,167, 43,172,9,
            129,22,39,253, 19,98,108,110,79,113,224,232,178,185, 112,104,218,246,97,228,
            251,34,242,193,238,210,144,12,191,179,162,241, 81,51,145,235,249,14,239,107,
            49,192,214, 31,181,199,106,157,184, 84,204,176,115,121,50,45,127, 4,150,254,
            138,236,205,93,222,114,67,29,24,72,243,141,128,195,78,66,215,61,156,180
        };
        for (int i=0; i < 256 ; i++) p[256+i] = p[i] = permutation[i];
    }
}
