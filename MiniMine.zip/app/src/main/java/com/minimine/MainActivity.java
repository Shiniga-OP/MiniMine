package com.minimine;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.Matrix;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.os.Looper;

/* 
O codigo atual é protegido por uma licença.

o codigo pode ser utilizado de todas as formas dentro das restrições a seguir:

-Não se pode alterar o idioma original do codigo, ou seja, portugues.
-Qualquer alteração no codigo e, quaisquer danos ou utilidades que dê a esse codigo, são responsabilidade totalmente sua.
-Não estamos associados ao que você fará a seguir com o codigo, então não deixe marcas ou indentificações que sejam originais do codigo.

qualquer alteracao, utilizacao ou adicao ao codigo deve respeitar as regras, juntamente da natividade do idioma original do codigo atual.

faça bom uso.
*/

// verificacoes podem afetar a performace, Log.e é inutil, ja que no android, esses logs so sao exibidos crashando a aplicacao 2 vezes seguidas

public class MainActivity extends Activity {
    private GLSurfaceView tela;
    private GLRender render;

    private Handler responsavel = new Handler();
    private Runnable movimentoRepetitivo;

    private TextView coordenadas;
    private EditText chat;
    
    private EditText console;
    private Logs log;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        coordenadas = findViewById(R.id.coordenadas);
        chat = findViewById(R.id.chat);
        
        console = findViewById(R.id.logs);
        
        log = new Logs();
        log.capturar();
        
        tela = findViewById(R.id.tela);
        tela.setEGLContextClientVersion(3);

        render = new GLRender(this, tela);
        tela.setRenderer(render);
        tela.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        prepararControles();
        
        render.camera.mover(0.5f);
        
    }
	
	public void pular(View view) {
		if(render.mundo.noChao(render.camera)) {
			for(int i=0; i<500; i++) {
				render.camera.posicao[1] += render.camera.salto; // forca de pulo
				float[] posAjustada = render.mundo.verificarColisao(render.camera, render.camera.posicao[0], render.camera.posicao[1], render.camera.posicao[2]);
				render.camera.posicao[1] = posAjustada[1];
			}
		}
	}
	
	public void colocarBloco(View view) {
		colocarBlocoAlcance(render.camera.itemMao);
		// camada 1:
		comandos("/bloco 0 33 0 pedregulho");
		comandos("/bloco 1 33 0 pedregulho");
		comandos("/bloco 2 33 0 pedregulho");
		comandos("/bloco 3 33 0 pedregulho");
		comandos("/bloco 4 33 0 pedregulho");
		comandos("/bloco 5 33 0 pedregulho");
		
		comandos("/bloco 5 33 1 pedregulho");
		comandos("/bloco 5 33 2 pedregulho");
		comandos("/bloco 5 33 3 pedregulho");
		comandos("/bloco 5 33 4 pedregulho");
		
		comandos("/bloco 4 33 4 pedregulho");
		comandos("/bloco 3 33 4 pedregulho");
		comandos("/bloco 2 33 4 pedregulho");
		comandos("/bloco 1 33 4 pedregulho");
		comandos("/bloco 0 33 4 pedregulho");
		comandos("/bloco 0 33 3 pedregulho");
		comandos("/bloco 0 33 1 pedregulho");
		
		// camada 2:
		comandos("/bloco 0 34 0 pedregulho");
		comandos("/bloco 1 34 0 pedregulho");
		comandos("/bloco 2 34 0 pedregulho");
		comandos("/bloco 3 34 0 pedregulho");
		comandos("/bloco 4 34 0 pedregulho");
		comandos("/bloco 5 34 0 pedregulho");

		comandos("/bloco 5 34 1 pedregulho");
		comandos("/bloco 5 34 2 pedregulho");
		comandos("/bloco 5 34 3 pedregulho");
		comandos("/bloco 5 34 4 pedregulho");

		comandos("/bloco 4 34 4 pedregulho");
		comandos("/bloco 3 34 4 pedregulho");
		comandos("/bloco 2 34 4 pedregulho");
		comandos("/bloco 1 34 4 pedregulho");
		comandos("/bloco 0 34 4 pedregulho");
		comandos("/bloco 0 34 3 pedregulho");
		comandos("/bloco 0 34 1 pedregulho");
		
		// camada 3:
		comandos("/bloco 0 35 0 pedregulho");
		comandos("/bloco 1 35 0 pedregulho");
		comandos("/bloco 2 35 0 pedregulho");
		comandos("/bloco 3 35 0 pedregulho");
		comandos("/bloco 4 35 0 pedregulho");
		comandos("/bloco 5 35 0 pedregulho");

		comandos("/bloco 5 35 1 pedregulho");
		comandos("/bloco 5 35 2 pedregulho");
		comandos("/bloco 5 35 3 pedregulho");
		comandos("/bloco 5 35 4 pedregulho");

		comandos("/bloco 4 35 4 pedregulho");
		comandos("/bloco 3 35 4 pedregulho");
		comandos("/bloco 2 35 4 pedregulho");
		comandos("/bloco 1 35 4 pedregulho");
		comandos("/bloco 0 35 4 pedregulho");
		comandos("/bloco 0 35 3 pedregulho");
		comandos("/bloco 0 35 2 pedregulho");
		comandos("/bloco 0 35 1 pedregulho");
	}
	
	public void colocarBlocoAlcance(TipoBloco tipo) {
		float[] pos = render.camera.posicao;
		float[] foco = render.camera.foco;

		// calcula o vetor de direcao e normaliza
		float dx = foco[0] - pos[0];
		float dy = foco[1] - pos[1];
		float dz = foco[2] - pos[2];
		float dist = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
		dx /= dist;
		dy /= dist;
		dz /= dist;

		float maxDist = render.camera.alcance;
		float passo = 0.1f;
		float distAtual = 0f;
		// ultima posicao sem colisao
		float ultimoX = pos[0], ultimoY = pos[1], ultimoZ = pos[2];
		boolean encontrou = false;

		// itera ao longo do raio ate o alcance maximo
		while(distAtual <= maxDist) {
			float xAtual = pos[0] + dx * distAtual;
			float yAtual = pos[1] + dy * distAtual;
			float zAtual = pos[2] + dz * distAtual;

			int bx = (int) Math.floor(xAtual);
			int by = (int) Math.floor(yAtual);
			int bz = (int) Math.floor(zAtual);

			// se encontrou um bloco solido interrompe o loop
			if(render.mundo.eBlocoSolido(bx, by, bz)) {
				encontrou = true;
				break;
			}
			// atualiza a ultima posicao sem colisao
			ultimoX = xAtual;
			ultimoY = yAtual;
			ultimoZ = zAtual;
			distAtual += passo;
		}

		// se houve colisao, coloca o bloco na ultima posicao vazia encontrada
		if(encontrou) {
			int planoX = (int) Math.floor(ultimoX);
			int planoY = (int) Math.floor(ultimoY);
			int planoZ = (int) Math.floor(ultimoZ);
			render.mundo.colocarBloco(planoX, planoY, planoZ, tipo);
		}
	}

    private void prepararControles() {
        final Button btnFrente = findViewById(R.id.btnFrente);
        final Button btnEsquerda = findViewById(R.id.btnEsquerda);
        final Button btnDireita = findViewById(R.id.btnDireita);
        final Button btnTras = findViewById(R.id.btnTras);

        View.OnTouchListener movimentoAgendado = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent evento) {
                switch (evento.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        moviComecar(v);
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        moviParar();
                        break;
                }
                return true;
            }
        };

        btnFrente.setOnTouchListener(movimentoAgendado);
        btnEsquerda.setOnTouchListener(movimentoAgendado);
        btnDireita.setOnTouchListener(movimentoAgendado);
        btnTras.setOnTouchListener(movimentoAgendado);
    }
    
    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        
        if(e.getPointerCount() > 1 || action==MotionEvent.ACTION_MOVE) {
            return render.eventoToque(e);
        }
        return super.dispatchTouchEvent(e);
    }
    
    private void comandos(String comando) {
        console.setText(log.exibir());
        
        // tp:
        if(comando.startsWith("/tp ")) {
            comando = comando.replace("/tp ", "");
            String[] tokens = comando.trim().split(" ");
            
            render.camera.posicao[0] = Float.parseFloat(tokens[0].replace("~", String.valueOf(render.camera.posicao[0])));
            render.camera.posicao[1] = Float.parseFloat(tokens[1].replace("~", String.valueOf(render.camera.posicao[1])));
            render.camera.posicao[2] = Float.parseFloat(tokens[2].replace("~", String.valueOf(render.camera.posicao[2])));
			// chunk:
        } else if(comando.startsWith("/chunk raio ")) {
            comando = comando.replace("/chunk raio ", "");
            
            render.mundo.RAIO_CARREGAMENTO = Integer.parseInt(comando);
        } else if(comando.startsWith("/chunk tamanho")) {
            comando = comando.replace("/chunk tamanho ", "");
            
            render.mundo.CHUNK_TAMANHO = Integer.parseInt(comando);
			// bloco:
        } else if(comando.startsWith("/bloco ")) {
            comando = comando.replace("/bloco ", "");
            String[] tokens = comando.trim().split(" ");
            
            TipoBloco tipo = TipoBloco.GRAMA;
            
            switch(tokens[3]) {
                case "grama":
                    tipo = TipoBloco.GRAMA;
                    break;
				case "terra":
					tipo = TipoBloco.TERRA;
					break;
				case "pedra":
					tipo = TipoBloco.PEDRA;
					break;
				case "pedregulho":
					tipo = TipoBloco.PEDREGULHO;
					break;
				case "tabuas_carvalho":
					tipo = TipoBloco.TABUAS_CARVALHO;
					break;
				case "bedrock":
					tipo = TipoBloco.BEDROCK;
					break;
				default:
					System.out.print(tokens[3]+" isso não é um bloco disponivel");
					break;
            }
			if(tipo != null) render.mundo.colocarBloco(Float.parseFloat(tokens[0].replace("~", String.valueOf(render.camera.posicao[0]))), Float.parseFloat(tokens[1].replace("~", String.valueOf(render.camera.posicao[1]))), Float.parseFloat(tokens[2].replace("~", String.valueOf(render.camera.posicao[2]))), tipo);
			else System.out.println("erro");
			// player:
        } else if(comando.startsWith("/player mao")) {
			comando = comando.replace("/player mao ", "");
			
			switch(comando) {
				case "grama":
					render.camera.itemMao = TipoBloco.GRAMA;
					break;
				case "terra":
					render.camera.itemMao = TipoBloco.TERRA;
					break;
				case "pedra":
					render.camera.itemMao = TipoBloco.PEDRA;
					break;
				case "pedregulho":
					render.camera.itemMao = TipoBloco.PEDREGULHO;
					break;
				case "tabuas_carvalho":
					render.camera.itemMao = TipoBloco.TABUAS_CARVALHO;
					break;
				case "bedrock":
					render.camera.itemMao = TipoBloco.BEDROCK;
					break;
			}
		}
        chat.setText("");
    }

    private void moviComecar(final View v) {
        movimentoRepetitivo = new Runnable() {
            @Override
            public void run() {
                coordenadas.setText("X: "+Math.round(render.camera.posicao[0])+" Y: "+Math.round(render.camera.posicao[1])+" Z: "+Math.round(render.camera.posicao[2]));
                if(!chat.getText().toString().equals("")) comandos(chat.getText().toString());
                switch(v.getId()) {
                    case R.id.btnFrente:
                        render.moverFrente();
                        break;
                    case R.id.btnEsquerda:
                        render.moverEsquerda();
                        break;
                    case R.id.btnDireita:
                        render.moverDireita();
                        break;
                    case R.id.btnTras:
                        render.moverTras();
                        break;
                }
                responsavel.postDelayed(this, 50);
            }
        };
        responsavel.post(movimentoRepetitivo);
    }

    private void moviParar() {
        if (movimentoRepetitivo != null) {
            responsavel.removeCallbacks(movimentoRepetitivo);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        return render.eventoToque(e);
    }

    @Override
    protected void onResume() {
        super.onResume();
        tela.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        render.mundo.limparTexturas();
        tela.onPause();
    }
}

class Mundo {
    public static int CHUNK_TAMANHO = 16; // padrao: 16, testes: 8
    public static int MUNDO_LATERAL = 120; // padrao: 60, testes: 16
    public static int RAIO_CARREGAMENTO = 1; // padrao: 3, testes: 2, inicial: 15
    
    public static final int FACES_POR_BLOCO = 6;

    private int shaderPrograma;
    private int lidarvPMatriz;
    private int lidarPosicao;
    private int lidarTexCoord;
    private int lidarTexturas;
    
    private int lidarLuzDirecao;
    private int lidarNormal;
    private float[] luzDirecao = {0.5f, 1.0f, 0.5f};
    
    public HashMap<TipoBloco, int[]> texturasBlocos = new HashMap<>();
    
    public HashMap<String, Bloco[][][]> chunksAtivos = new HashMap<>();
    public HashMap<String, Bloco[][][]> chunksCarregados = new HashMap<>();
    
    public long ultimoCarr = 0;
    public final long intervaloCarr = 0;
	
	public String tipo = "plano";
    
    public HashMap<String, List<VBOGrupo>> chunkVBOs = new HashMap<>();
    
    public void colocarBloco(float globalX, float y, float globalZ, TipoBloco tipo) {
        // calcula a posicao do chunk com float
        int chunkX = (int) Math.floor(globalX / (float) CHUNK_TAMANHO);
        int chunkZ = (int) Math.floor(globalZ / (float) CHUNK_TAMANHO);
        String chaveChunk = chunkX + "," + chunkZ;

        // carrega ou gera o chunk
        Bloco[][][] chunk = carregarChunk(chunkX, chunkZ);
		
		int intY = (int) y;
		int localX = (int) (globalX - (chunkX * CHUNK_TAMANHO));
		int localZ = (int) (globalZ - (chunkZ * CHUNK_TAMANHO));
        // verifica limites
        if(y < 0 || y >= MUNDO_LATERAL || localX < 0 || localX >= CHUNK_TAMANHO || localZ < 0 || localZ >= CHUNK_TAMANHO) {
            return;
        }
		
		Bloco blocoExistente = chunk[localX][intY][localZ];
		if(blocoExistente != null && blocoExistente.tipo != TipoBloco.AR) {
			return;
		}

        // define o bloco com o novo tipo
        chunk[localX][(int) y][localZ] = new Bloco((int) globalX, (int) y, (int) globalZ, tipo);

        // se o chunk estiver ativo atualiza e recalcula seus VBOs
        if(chunksAtivos.containsKey(chaveChunk)) {
            chunksAtivos.put(chaveChunk, chunk);
            Map<Integer, List<float[]>> dados = calculoVBO(chunk);
            List<VBOGrupo> grupos = gerarVBO(dados);
            chunkVBOs.put(chaveChunk, grupos);
			chunksAtivos.remove(chaveChunk, chunk);
        }
    }
	
	public boolean eBlocoSolido(int bx, int by, int bz) {
		if(by < 0 || by >= MUNDO_LATERAL) {
			return false;
		}

		int chunkX = (int) Math.floor(bx / (float) CHUNK_TAMANHO);
		int chunkZ = (int) Math.floor(bz / (float) CHUNK_TAMANHO);
		String chaveChunk = chunkX + "," + chunkZ;

		if(!chunksAtivos.containsKey(chaveChunk)) {
			return false;
		}

		Bloco[][][] chunk = chunksAtivos.get(chaveChunk);

		int localX = bx - chunkX * CHUNK_TAMANHO;
		int localZ = bz - chunkZ * CHUNK_TAMANHO;

		if(localX < 0 || localX >= CHUNK_TAMANHO || localZ < 0 || localZ >= CHUNK_TAMANHO) {
			return false;
		}

		Bloco bloco = chunk[localX][by][localZ];
		return bloco != null && bloco.tipo.eSolido();
	}
	
	public float[] verificarColisao(Camera camera, float novoTx, float novoTy, float novoTz) {
		float[] posAntiga = camera.posicao;
		float atualX = posAntiga[0];
		float atualY = posAntiga[1]/1f;
		float atualZ = posAntiga[2];

		float dx = novoTx - atualX;
		float dy = novoTy - atualY;
		float dz = novoTz - atualZ;

		// tenta mover no eixo X
		float testX = atualX + dx;
		if(!colisao(camera, testX, atualY, atualZ)) {
			atualX = testX;
		}

		// tenta mover no eixo Z
		float testZ = atualZ + dz;
		if(!colisao(camera, atualX, atualY, testZ)) {
			atualZ = testZ;
		}

		// tenta mover no eixo Y
		float testY = atualY + dy;
		if(!colisao(camera, atualX, testY, atualZ)) {
			atualY = testY;
		}

		return new float[]{atualX, atualY, atualZ};
	}

	private boolean colisao(Camera camera, float x, float y, float z) {
		float altura = camera.hitbox[0];
		float largura = camera.hitbox[1];
		float half = largura / 2;

		for(int bx = (int)(x - half); bx <= (int)(x + half); bx++) {
			for(int by = (int)y; by <= (int)(y + altura); by++) {
				for(int bz = (int)(z - half); bz <= (int)(z + half); bz++) {
					if(eBlocoSolido(bx, by, bz)) {
						return true;
					}
				}
			}
		}
		return false;
	}
	
	public boolean noChao(Camera camera) {
		float x = camera.posicao[0];
		float y = camera.posicao[1]-1.5f;
		float z = camera.posicao[2];
		int by = (int) Math.floor(y - 0.1f);

		int bx1 = (int) Math.floor(x - 0.5f);
		int bx2 = (int) Math.floor(x + 0.5f);
		int bz1 = (int) Math.floor(z - 0.5f);
		int bz2 = (int) Math.floor(z + 0.5f);

		for(int bx = bx1; bx <= bx2; bx++) {
			for(int bz = bz1; bz <= bz2; bz++) {
				if(eBlocoSolido(bx, by, bz)) {
					return true;
				}
			}
		}
		return false;
	}
    
    public float[] obterNormalParaFace(int face) {
        switch(face) {
            case 0: // frente
                return new float[]{0f, 0f, 1f};
            case 1: // tras
                return new float[]{0f, 0f, -1f};
            case 2: // cima
                return new float[]{0f, 1f, 0f};
            case 3: // baixo
                return new float[]{0f, -1f, 0f};
            case 4: // esquerda
                return new float[]{-1f, 0f, 0f};
            case 5: // direita
                return new float[]{1f, 0f, 0f};
            default:
                return new float[]{0f, 0f, 0f};
        }
    }
    
    public boolean faceVisivel(int x, int y, int z, int face) {
        int dx = 0, dy = 0, dz = 0;
        switch(face) {
            case 0: dz = 1; break;
            case 1: dz = -1; break;
            case 2: dy = 1; break;
            case 3: dy = -1; break;
            case 4: dx = -1; break;
            case 5: dx = 1; break;
        }

        int nx = x + dx;
        int ny = y + dy;
        int nz = z + dz;

        // verificacao de limites verticais
        if (ny < 0 || ny >= MUNDO_LATERAL) return true;

        // calculo de coordenadas de chunk
        int chunkX = (int) Math.floor(nx / (float)CHUNK_TAMANHO);
        int chunkZ = (int) Math.floor(nz / (float)CHUNK_TAMANHO);
        String chaveChunk = chunkX + "," + chunkZ;

        // verificação de chunk carregado
        if(!chunksAtivos.containsKey(chaveChunk)) return true;

        Bloco[][][] chunkVizinho = chunksAtivos.get(chaveChunk);
        if(chunkVizinho==null) return true;

        // conversao para coordenadas locais
        int localX = nx - (chunkX * CHUNK_TAMANHO);
        int localZ = nz - (chunkZ * CHUNK_TAMANHO);

        // ajuste para valores negativos
        if(localX < 0) localX += CHUNK_TAMANHO;
        if(localZ < 0) localZ += CHUNK_TAMANHO;

        // verificacao de indices
        if(localX >= CHUNK_TAMANHO || localZ >= CHUNK_TAMANHO) return true;

        try {
            Bloco vizinho = chunkVizinho[localX][ny][localZ];
            return vizinho==null || vizinho.tipo==TipoBloco.AR || !vizinho.tipo.eSolido();
        } catch(ArrayIndexOutOfBoundsException e) {
            return true;
        }
    }

    public Map<Integer, List<float[]>> calculoVBO(Bloco[][][] chunk) {
        HashMap<Integer, List<float[]>> dadosPorTextura = new HashMap<>();

        for(int x = 0; x < CHUNK_TAMANHO; x++) {
            for(int y = 0; y < MUNDO_LATERAL; y++) {
                for(int z = 0; z < CHUNK_TAMANHO; z++) {
                    Bloco bloco = chunk[x][y][z];
                    if(bloco.tipo==TipoBloco.AR) continue;

                    for(int face = 0; face < 6; face++) {
                        if(!faceVisivel(bloco.x, bloco.y, bloco.z, face)) continue;

                        int texturaId = texturasBlocos.get(bloco.tipo)[face];
                        float[] dadosFace = new float[6 * 8]; // 8 atributos por vertice

                        // preencher dados da face
                        for(int v = 0; v < 6; v++) {
                            int ultimaVertice = (face * 18) + (v * 3);
                            int ultimaTex = (face * 12) + (v * 2);
                            int ultimoBuffer = v * 8;

                            System.arraycopy(bloco.obterVertices(), ultimaVertice, dadosFace, ultimoBuffer, 3);

                            float[] normal = obterNormalParaFace(face);
                            System.arraycopy(normal, 0, dadosFace, ultimoBuffer + 3, 3);

                            System.arraycopy(bloco.obterCoordenadas(), ultimaTex, dadosFace, ultimoBuffer + 6, 2);
                        }

                        if(!dadosPorTextura.containsKey(texturaId)) {
                            dadosPorTextura.put(texturaId, new ArrayList<float[]>());
                        }
                        dadosPorTextura.get(texturaId).add(dadosFace);
                        }
                    }
                }
            }
            return dadosPorTextura;
        }
        
    public List<VBOGrupo> gerarVBO(Map<Integer, List<float[]>> dadosPorTextura) {
        List<VBOGrupo> grupos = new ArrayList<>();
        for(Map.Entry<Integer, List<float[]>> entry : dadosPorTextura.entrySet()) {
            int texturaId = entry.getKey();
            int totalVertices = 0;

            for(float[] arr : entry.getValue()) {
                totalVertices += arr.length / 8;
            }

            FloatBuffer buffer = ByteBuffer.allocateDirect(totalVertices * 8 * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer();

            for(float[] dados : entry.getValue()) {
                buffer.put(dados);
            }
            buffer.position(0);

            int[] vboIds = new int[1];
            GLES30.glGenBuffers(1, vboIds, 0);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vboIds[0]);
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, buffer.capacity() * 4, buffer, GLES30.GL_STATIC_DRAW);

            grupos.add(new VBOGrupo(texturaId, vboIds[0], totalVertices));
        }
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0);
        return grupos;
    }
  
    // gera ou carrega chunks ja existentes
    public Bloco[][][] carregarChunk(int chunkX, int chunkY) {
        String chave = chunkX + "," + chunkY;
        if(chunksCarregados.containsKey(chave)) {
            return chunksCarregados.get(chave);
        }
        else {
            Bloco[][][] chunk = gerarChunk(chunkX, chunkY);
            chunksCarregados.put(chave, chunk);
            return chunk;
        }
    }

        // gera um chunk especifico
        public Bloco[][][] gerarChunk(int chunkX, int chunkZ) {
            Bloco[][][] chunk = new Bloco[CHUNK_TAMANHO][MUNDO_LATERAL][CHUNK_TAMANHO];
            for(int x = 0; x < CHUNK_TAMANHO; x++) {
                for(int z = 0; z < CHUNK_TAMANHO; z++) {
                    // converte para cordenadas globais
                    int globalX = chunkX * CHUNK_TAMANHO + x;
                    int globalZ = chunkZ * CHUNK_TAMANHO + z;
                    
                    int seed = 123456789; // testes
                    
                    // gera terreno
                    float valorNoise = 0f;
					if(tipo.equals("plano")) valorNoise = PerlinNoise.ruido(globalX / 1f, globalZ / 1f, seed);
					if(tipo.equals("normal")) valorNoise = PerlinNoise.ruido(globalX / 50f, globalZ / 50f, seed);
					
                    int lateral = (int)(valorNoise * 16 + 32);

                    for(int y = 0; y < MUNDO_LATERAL; y++) {
                        TipoBloco tipo = TipoBloco.AR;
                        if(y==0) tipo = TipoBloco.BEDROCK;
                        else if(y < lateral - 1) tipo = TipoBloco.PEDRA;
                        else if(y < lateral) tipo = TipoBloco.TERRA;
                        else if(y==lateral) tipo = TipoBloco.GRAMA;

                        chunk[x][y][z] = new Bloco(globalX, y, globalZ, tipo);
                    }
                }
            }
            return chunk;
        }
        
    public void renderizar(float[] vpMatriz) {
        GLES30.glUseProgram(shaderPrograma);
        GLES30.glUniformMatrix4fv(lidarvPMatriz, 1, false, vpMatriz, 0);
        GLES30.glUniform3fv(lidarLuzDirecao, 1, luzDirecao, 0);

        // renderiza cada chunk ativo utilizando os VBOs gerados
        for(Map.Entry<String, Bloco[][][]> entry : chunksAtivos.entrySet()) {
            String chave = entry.getKey();
            List<VBOGrupo> grupos = chunkVBOs.get(chave);
            if(grupos==null) continue;
            for (VBOGrupo grupo : grupos) {
                GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, grupo.texturaId);
                GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, grupo.vboId);

                GLES30.glVertexAttribPointer(lidarPosicao, 3, GLES30.GL_FLOAT, false, 8 * 4, 0);
                GLES30.glEnableVertexAttribArray(lidarPosicao);

                GLES30.glVertexAttribPointer(lidarNormal, 3, GLES30.GL_FLOAT, false, 8 * 4, 3 * 4);
                GLES30.glEnableVertexAttribArray(lidarNormal);

                GLES30.glVertexAttribPointer(lidarTexCoord, 2, GLES30.GL_FLOAT, false, 8 * 4, 6 * 4);
                GLES30.glEnableVertexAttribArray(lidarTexCoord);

                GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, grupo.vertices);
            }
        }
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0);
    }

    public void iniciarShaders(Context contexto) {
        String shaderVertice =
            "uniform mat4 u_VPMatriz;" +
            "uniform vec3 u_direcaoLuz;" +
            "attribute vec4 a_Posicao;" +
            "attribute vec3 a_Normal;" +
            "attribute vec2 a_TexCoord;" +
            "varying vec2 v_TexCoord;" +
            "varying float v_intencidadeLuz;" +
            "void main() {" +
            "   gl_Position = u_VPMatriz * a_Posicao;" +
            "   v_TexCoord = a_TexCoord;" +
            "   v_intencidadeLuz = max(dot(normalize(a_Normal), normalize(u_direcaoLuz)), 0.95);" +
            "}";

        String shaderFragmento =
            "precision mediump float;" +
            "varying vec2 v_TexCoord;" +
            "varying float v_intencidadeLuz;" +
            "uniform sampler2D u_Textura;" +
            "void main() {" +
            "   vec4 corTextura = texture2D(u_Textura, v_TexCoord);" +
            "   gl_FragColor = vec4(corTextura.rgb * v_intencidadeLuz, corTextura.a);" +
            "}";

        shaderPrograma = ShaderUtils.criarPrograma(shaderVertice, shaderFragmento);
        lidarvPMatriz = GLES30.glGetUniformLocation(shaderPrograma, "u_VPMatriz");
        lidarLuzDirecao = GLES30.glGetUniformLocation(shaderPrograma, "u_direcaoLuz");
        lidarPosicao = GLES30.glGetAttribLocation(shaderPrograma, "a_Posicao");
        lidarNormal = GLES30.glGetAttribLocation(shaderPrograma, "a_Normal");
        lidarTexCoord = GLES30.glGetAttribLocation(shaderPrograma, "a_TexCoord");
        lidarTexturas = GLES30.glGetUniformLocation(shaderPrograma, "u_Textura");
    }

    public void carregarTexturas(Context contexto) {
        for(TipoBloco tipo : TipoBloco.values()) {
            if(tipo==TipoBloco.AR) continue;

            int[] texturasFace = new int[FACES_POR_BLOCO];
            GLES30.glGenTextures(FACES_POR_BLOCO, texturasFace, 0);

            for(int face = 0; face < FACES_POR_BLOCO; face++) {
                int recurso = tipo.obterRecursoTextura(face);
                if(recurso==-1) continue;

                GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, texturasFace[face]);
				
                GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST);
                GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST);

                Bitmap bitmap = BitmapFactory.decodeResource(contexto.getResources(), recurso);
                GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bitmap, 0);
                bitmap.recycle();
            }
            texturasBlocos.put(tipo, texturasFace);
        }
    }
    
    public void limparTexturas() {
        for(int[] ids : texturasBlocos.values()) {
            GLES30.glDeleteTextures(ids.length, ids, 0);
        }
    }
}
