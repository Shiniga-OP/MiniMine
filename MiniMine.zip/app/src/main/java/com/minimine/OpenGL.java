package com.minimine;

import android.content.Context;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.view.MotionEvent;
import javax.microedition.khronos.opengles.GL10;
import android.opengl.GLES30;

import android.opengl.Matrix;
import java.util.Iterator;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import android.opengl.GLSurfaceView;
import javax.microedition.khronos.egl.EGLConfig;
import java.nio.FloatBuffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.io.InputStream;

public class OpenGL {
    
}

class GLRender implements GLSurfaceView.Renderer {
    private final Context contexto;
    private final GLSurfaceView tela;
    private final float[] projecaoMatriz = new float[16];
    private final float[] viewMatriz = new float[16];
    private final float[] vpMatriz = new float[16];

    public Mundo mundo;
    public Player camera;

    public String modo = "teste";
    public int chunksPorVez;
    private ExecutorService executor = Executors.newFixedThreadPool(2);

    private Thread chunkAtualizador;
    private boolean atualizarChunksRodando = true;

    private int pontoAtivo = -1;
    private float ultimoX, ultimoY;

    public boolean eventoToque(MotionEvent e) {
        int acao = e.getActionMasked();
        switch(acao) {
            case MotionEvent.ACTION_DOWN:
                pontoAtivo = e.getPointerId(0);
                ultimoX = e.getX(0);
                ultimoY = e.getY(0);
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                if(pontoAtivo==-1) {
                    int indice = e.getActionIndex();
                    pontoAtivo = e.getPointerId(indice);
                    ultimoX = e.getX(indice);
                    ultimoY = e.getY(indice);
                }
                break;
            case MotionEvent.ACTION_MOVE:
                int indicePonto = e.findPointerIndex(pontoAtivo);
                if(indicePonto != -1) {
                    float x = e.getX(indicePonto);
                    float y = e.getY(indicePonto);
                    float dx = x - ultimoX;
                    float dy = y - ultimoY;
                    camera.rotacionar(dx * 0.15f, dy * 0.15f);
                    atualizarViewMatriz();
                    ultimoX = x;
                    ultimoY = y;
                }
                break;
            case MotionEvent.ACTION_POINTER_UP:
                // se o dedo ativo foi levantado escolhe outro que esteja tocando
                int ponto = e.getPointerId(e.getActionIndex());
                if(ponto==pontoAtivo) {
                    int novoIndice = (e.getActionIndex()==0 ? 1 : 0);
                    pontoAtivo = e.getPointerId(novoIndice);
                    ultimoX = e.getX(novoIndice);
                    ultimoY = e.getY(novoIndice);
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                pontoAtivo = -1;
                break;
        }
        return true;
    }

    // construtor que recebe o contexto e a tela
    public GLRender(Context contexto, GLSurfaceView tela) {
        this.contexto = contexto;
        this.tela = tela;
        this.camera = new Player();
    }
    
    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES30.glClearColor(0.53f, 0.81f, 0.98f, 1.0f);
        GLES30.glEnable(GLES30.GL_DEPTH_TEST);

        this.mundo = new Mundo();
        if(modo.equals("alpha")) this.mundo.RAIO_CARREGAMENTO = 2;
        if(modo.equals("teste")) this.mundo.RAIO_CARREGAMENTO = 1;
        this.chunksPorVez = 0;
        this.mundo.iniciarShaders(contexto);
        this.mundo.carregarTexturas(contexto);
        atualizarViewMatriz();
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);
		if(!mundo.noChao(camera)) {
			float novaY = camera.posicao[1] - 0.15f;
			float[] pos = mundo.verificarColisao(camera, camera.posicao[0], novaY, camera.posicao[2]);
			camera.posicao[1] = pos[1];
		}
		
		atualizarChunks(camera.posicao[0], camera.posicao[2]);

		Matrix.multiplyMM(vpMatriz, 0, projecaoMatriz, 0, viewMatriz, 0);
		mundo.renderizar(vpMatriz);
		
		atualizarViewMatriz();
    }

    public void atualizarChunks(float posX, float posZ) {
        
        int chunkJogadorX = (int) Math.floor(posX / mundo.CHUNK_TAMANHO);
        int chunkJogadorZ = (int) Math.floor(posZ / mundo.CHUNK_TAMANHO);

        // descarrega chunks fora do raio
        Iterator<Map.Entry<String, Bloco[][][]>> iterator = mundo.chunksAtivos.entrySet().iterator();
        while(iterator.hasNext()) {
            Map.Entry<String, Bloco[][][] > entry = iterator.next();
            String[] coordenadas = entry.getKey().split(",");
            int chunkX = Integer.parseInt(coordenadas[0]);
            int chunkZ = Integer.parseInt(coordenadas[1]);

            if(Math.abs(chunkX - chunkJogadorX) > mundo.RAIO_CARREGAMENTO || Math.abs(chunkZ - chunkJogadorZ) > mundo.RAIO_CARREGAMENTO) {
                iterator.remove();
                // libera os VBOs do chunk removido
                if(mundo.chunkVBOs.containsKey(entry.getKey())) {
                    for(VBOGrupo grupo : mundo.chunkVBOs.get(entry.getKey())) {
                        int[] buffer = { grupo.vboId };
                        GLES30.glDeleteBuffers(1, buffer, 0);
                    }
                    mundo.chunkVBOs.remove(entry.getKey());
                }
            }
        }

        // jdentifica chunks candidatos a serem carregados
        List<String> candidatos = new ArrayList<>();
        for(int x = chunkJogadorX - mundo.RAIO_CARREGAMENTO; x <= chunkJogadorX + mundo.RAIO_CARREGAMENTO; x++) {
            for(int z = chunkJogadorZ - mundo.RAIO_CARREGAMENTO; z <= chunkJogadorZ + mundo.RAIO_CARREGAMENTO; z++) {
                String chave = x + "," + z;
                if(!mundo.chunksAtivos.containsKey(chave)) {
                    candidatos.add(chave);
                }
            }
        }

        // carrega apenas um chunk novo por chamada
         if(!(candidatos.size() <= this.chunksPorVez)) {
            final String chave = candidatos.get(0);
            String[] coords = chave.split(",");
            int x = Integer.parseInt(coords[0]);
            int z = Integer.parseInt(coords[1]);
            final Bloco[][][] chunk = mundo.carregarChunk(x, z);
            mundo.chunksAtivos.put(chave, chunk);

            executor.submit(new Runnable() {
                    @Override
                    public void run() {
                        final Map<Integer, List<float[]>> dados = mundo.calculoVBO(chunk);
						
                        tela.queueEvent(new Runnable() {
                                @Override
                                public void run() {
                                    List<VBOGrupo> grupos = mundo.gerarVBO(dados);
                                    mundo.chunkVBOs.put(chave, grupos);
                                }
                            });
                    }
                });
        }
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int horizontal, int lateral) {
        GLES30.glViewport(0, 0, horizontal, lateral);
        float ratio = (float) horizontal / lateral;
        Matrix.perspectiveM(projecaoMatriz, 0, 90, ratio, 0.1f, 1000f);
    }

    public void moverFrente() {
		// movimento apenas no X e Z, se a camera ta olhando pra cima
		float[] direcao = {
			camera.foco[0], 
			0, // remove Y
			camera.foco[2]
		};

		// normaliza o vetor
		float mag = (float)Math.sqrt(direcao[0]*direcao[0] + direcao[2]*direcao[2]);
		if(mag > 0) {
			direcao[0] /= mag;
			direcao[2] /= mag;
		}

		float novaX = camera.posicao[0] + direcao[0] * camera.velocidade;
		float novaZ = camera.posicao[2] + direcao[2] * camera.velocidade;

		// aplica colisao sem alterar Y
		float[] pos = mundo.verificarColisao(camera, novaX, camera.posicao[1], novaZ);
		camera.posicao[0] = pos[0];
		camera.posicao[2] = pos[2];

		atualizarViewMatriz();
	}

	public void moverTras() {
		float[] direcao = {
			camera.foco[0], 
			0, // remove Y
			camera.foco[2]
		};

		float mag = (float)Math.sqrt(direcao[0]*direcao[0] + direcao[2]*direcao[2]);
		if(mag > 0) {
			direcao[0] /= mag;
			direcao[2] /= mag;
		}

		float novaX = camera.posicao[0] + direcao[0] * -camera.velocidade;
		float novaZ = camera.posicao[2] + direcao[2] * -camera.velocidade;

		float[] pos = mundo.verificarColisao(camera, novaX, camera.posicao[1], novaZ);
		camera.posicao[0] = pos[0];
		camera.posicao[2] = pos[2];

		atualizarViewMatriz();
	}

	public void moverEsquerda() {
		float[] vetorDireito = {
			camera.foco[2] * camera.up[1] - camera.foco[1] * camera.up[2],
			camera.foco[0] * camera.up[2] - camera.foco[2] * camera.up[0],
			camera.foco[1] * camera.up[0] - camera.foco[0] * camera.up[1]
		};

		float novaX = camera.posicao[0] + vetorDireito[0] * -camera.velocidade;
		float novaY = camera.posicao[1] + vetorDireito[1] * -camera.velocidade;
		float novaZ = camera.posicao[2] + vetorDireito[2] * -camera.velocidade;

		float[] posAjustada = mundo.verificarColisao(camera, novaX, novaY, novaZ);
		camera.posicao[0] = posAjustada[0];
		camera.posicao[1] = posAjustada[1];
		camera.posicao[2] = posAjustada[2];

		atualizarViewMatriz();
	}

	public void moverDireita() {
		float[] vetorDireito = {
			camera.foco[2] * camera.up[1] - camera.foco[1] * camera.up[2],
			camera.foco[0] * camera.up[2] - camera.foco[2] * camera.up[0],
			camera.foco[1] * camera.up[0] - camera.foco[0] * camera.up[1]
		};

		float novaX = camera.posicao[0] + vetorDireito[0] * camera.velocidade;
		float novaY = camera.posicao[1] + vetorDireito[1] * camera.velocidade;
		float novaZ = camera.posicao[2] + vetorDireito[2] * camera.velocidade;

		float[] posAjustada = mundo.verificarColisao(camera, novaX, novaY, novaZ);
		camera.posicao[0] = posAjustada[0];
		camera.posicao[1] = posAjustada[1];
		camera.posicao[2] = posAjustada[2];

		atualizarViewMatriz();
	}

    private void atualizarViewMatriz() {
        Matrix.setLookAtM(viewMatriz, 0,
                          camera.posicao[0], camera.posicao[1], camera.posicao[2],
                          camera.posicao[0] + camera.foco[0],
                          camera.posicao[1] + camera.foco[1],
                          camera.posicao[2] + camera.foco[2],
                          camera.up[0], camera.up[1], camera.up[2]);
    }

    public void pararAtualizador() {
        atualizarChunksRodando = false;
        if(chunkAtualizador != null) {
            chunkAtualizador.interrupt();
        }
    }
}

class ShaderUtils {
    public static int carregarShader(int tipo, String shaderCodigo) {
        int shader = GLES30.glCreateShader(tipo);
        GLES30.glShaderSource(shader, shaderCodigo);
        GLES30.glCompileShader(shader);
        return shader;
    }

    public static int criarPrograma(String shaderVerticesCodigo, String shaderFragmentoCodigo) {
        int verticesShader = carregarShader(GLES30.GL_VERTEX_SHADER, shaderVerticesCodigo);
        int fragmentoShader = carregarShader(GLES30.GL_FRAGMENT_SHADER, shaderFragmentoCodigo);

        int programa = GLES30.glCreateProgram();
        GLES30.glAttachShader(programa, verticesShader);
        GLES30.glAttachShader(programa, fragmentoShader);
        GLES30.glLinkProgram(programa);
        return programa;
    }

    public static FloatBuffer criarBufferFloat(float[] dados) {
        ByteBuffer bb = ByteBuffer.allocateDirect(dados.length * 4);
        bb.order(ByteOrder.nativeOrder());
        FloatBuffer fb = bb.asFloatBuffer();
        fb.put(dados);
        fb.position(0);
        return fb;
    }

    public static String lerShaderDoRaw(Context contexto, int resId) {
        try {
            InputStream is = contexto.getResources().openRawResource(resId);
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            return new String(buffer);
        } catch(Exception e) {
            return null;
        }
    }
}
