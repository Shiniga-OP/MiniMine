package com.minimine;

public class Bloco {
    public int x, y, z;
    public TipoBloco tipo;

    public Bloco(int x, int y, int z, TipoBloco tipo) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.tipo = tipo;
    }

    public float[] obterVertices() {
        return new float[] {
            // face de frente
            x, y, z+1, x+1, y, z+1, x+1, y+1, z+1,
            x, y, z+1, x+1, y+1, z+1, x, y+1, z+1,

            // face de tras
            x, y, z, x+1, y, z, x+1, y+1, z,
            x, y, z, x+1, y+1, z, x, y+1, z,

            // face de cima
            x, y+1, z, x+1, y+1, z, x+1, y+1, z+1,
            x, y+1, z, x+1, y+1, z+1, x, y+1, z+1,

            // face de baixo
            x, y, z, x+1, y, z, x+1, y, z+1,
            x, y, z, x+1, y, z+1, x, y, z+1,

            // face esquerda
            x, y, z, x, y+1, z, x, y+1, z+1,
            x, y, z, x, y+1, z+1, x, y, z+1,

            // face direita
            x+1, y, z, x+1, y+1, z, x+1, y+1, z+1,
            x+1, y, z, x+1, y+1, z+1, x+1, y, z+1
        };
    }

    public float[] obterCoordenadas() {
        return new float[] {
            // face de frente
            0,1, 1,1, 1,0,
            0,1, 1,0, 0,0,

            // face de trás
            0,1, 1,1, 1,0,
            0,1, 1,0, 0,0,

            // face de cima
            0,1, 1,1, 1,0,
            0,1, 1,0, 0,0,

            // face de baixo
            0,1, 1,1, 1,0,
            0,1, 1,0, 0,0,

            // face esquerda
            0,1, 0,0, 1,0,
            0,1, 1,0, 1,1,

            // face direita
            0,1, 0,0, 1,0,
            0,1, 1,0, 1,1
        };
    }
}
